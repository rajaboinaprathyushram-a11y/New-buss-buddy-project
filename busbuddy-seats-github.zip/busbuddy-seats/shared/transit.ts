export type UserRole = 'commuter' | 'conductor';

export interface UserProfile {
  id: string;
  name: string;
  identifier: string;
  role: UserRole;
  depotOrVillage: string;
}

export interface LandmarkStop {
  stopId: string;
  villageName: string;
  landmarkName: string;
  stageIndex: number;
  distanceKm: number;
  etaOffsetMins: number;
}

export interface RuralRoute {
  id: string;
  routeNumber: string;
  name: string;
  busType: 'Palle Velugu' | 'Express Feeder' | 'Village Ordinary';
  baseFare: number;
  stageRate: number;
  stops: LandmarkStop[];
}

export type SeatStatus = 'available' | 'occupied' | 'female';

export interface BusSeat {
  seatNumber: string;
  row: number;
  column: number;
  side: 'left' | 'right';
  isWindow: boolean;
  status: SeatStatus;
}

export type TripAvailabilityStatus = 'Available' | 'Standing Only' | 'Full';

export type CrowdLevel =
  | 'Seats Plenty'
  | 'Bus is 80% Full'
  | 'Standing Only'
  | 'Bus Full';

export interface CrowdPing {
  level: CrowdLevel;
  reportedBy: string;
  stopName: string;
  reportedAt: string;
}

export interface ConductorLogEntry {
  id: string;
  actionLabel: string;
  previousSeats: number;
  newSeats: number;
  conductorName: string;
  timestamp: string;
}

export interface BusTrip {
  tripId: string;
  routeId: string;
  routeNumber: string;
  busRegistration: string;
  departureTime: string;
  departureInMins: number;
  totalSeats: number;
  availableSeats: number;
  status: TripAvailabilityStatus;
  currentStopName: string;
  seats: BusSeat[];
  crowdPing: CrowdPing | null;
  recentLogs: ConductorLogEntry[];
  lastUpdatedAt: string;
}

export interface FareBreakdown {
  baseFare: number;
  stageRate: number;
  stages: number;
  seatCount: number;
  singleSeatGross: number;
  grossFare: number;
  discountAmount: number;
  finalFare: number;
  studentConcessionApplied: boolean;
}

export interface TicketPass {
  ticketId: string;
  tripId: string;
  routeNumber: string;
  routeName: string;
  busRegistration: string;
  departureTime: string;
  passengerName: string;
  passengerPhone: string;
  boardingVillage: string;
  boardingLandmark: string;
  dropVillage: string;
  dropLandmark: string;
  seatNumbers: string[];
  stages: number;
  studentConcession: boolean;
  studentPassId?: string;
  farePaid: number;
  upiId: string;
  upiRef: string;
  issuedAt: string;
  userId: string;
}

export type RealtimeEvent =
  | { type: 'trips:snapshot'; trips: BusTrip[] }
  | { type: 'trip:updated'; trip: BusTrip }
  | { type: 'ticket:booked'; trip: BusTrip; ticketId: string };
