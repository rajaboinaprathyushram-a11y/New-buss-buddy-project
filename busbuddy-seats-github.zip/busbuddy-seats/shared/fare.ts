import type { FareBreakdown, LandmarkStop, RuralRoute } from './transit';

const STUDENT_CONCESSION_RATE = 0.4;
const MINIMUM_PASSENGER_FARE = 10;

export function calculateStageFare(
  route: Pick<RuralRoute, 'baseFare' | 'stageRate'>,
  boardingStop: LandmarkStop,
  dropStop: LandmarkStop,
  seatCount: number,
  studentConcession: boolean
): FareBreakdown {
  const safeSeatCount = Math.max(1, Math.min(6, Math.floor(seatCount)));
  const rawStages = Math.abs(dropStop.stageIndex - boardingStop.stageIndex);
  const stages = Math.max(1, rawStages);

  const singleSeatGross = route.baseFare + stages * route.stageRate;
  const grossFare = singleSeatGross * safeSeatCount;

  if (studentConcession) {
    // Student bus pass concession applies 40% subsidy to the first passenger seat
    const discountedFirstSeat = Math.max(
      MINIMUM_PASSENGER_FARE,
      Math.round(singleSeatGross * (1 - STUDENT_CONCESSION_RATE))
    );
    const remainingSeatsFare = singleSeatGross * (safeSeatCount - 1);
    const finalFare = discountedFirstSeat + remainingSeatsFare;
    const discountAmount = grossFare - finalFare;

    return {
      baseFare: route.baseFare,
      stageRate: route.stageRate,
      stages,
      seatCount: safeSeatCount,
      singleSeatGross,
      grossFare,
      discountAmount,
      finalFare,
      studentConcessionApplied: true,
    };
  }

  return {
    baseFare: route.baseFare,
    stageRate: route.stageRate,
    stages,
    seatCount: safeSeatCount,
    singleSeatGross,
    grossFare,
    discountAmount: 0,
    finalFare: grossFare,
    studentConcessionApplied: false,
  };
}
