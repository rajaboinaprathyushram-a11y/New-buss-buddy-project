import { useCallback, useEffect, useRef, useState } from 'react';
import type { BusTrip, RealtimeEvent, RuralRoute } from '../../shared/transit';
import { fetchRoutesAndTrips } from '../services/api';
import { loadTimetableCache, saveTimetableCache } from '../utils/offlineCache';

export type SyncStatus = 'live' | 'reconnecting' | 'offline';

export function useRealtimeTrips() {
  const [routes, setRoutes] = useState<RuralRoute[]>([]);
  const [trips, setTrips] = useState<BusTrip[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('reconnecting');
  const [cachedAt, setCachedAt] = useState<string | null>(null);

  const routesRef = useRef<RuralRoute[]>([]);
  routesRef.current = routes;

  const loadInitial = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchRoutesAndTrips();
      setRoutes(data.routes);
      setTrips(data.trips);
      saveTimetableCache(data.routes, data.trips);
      setCachedAt(new Date().toISOString());
    } catch {
      const cached = loadTimetableCache();
      if (cached) {
        setRoutes(cached.routes);
        setTrips(cached.trips);
        setCachedAt(cached.cachedAt);
        setSyncStatus('offline');
        setError('Unable to reach server. Showing offline cached district timetable.');
      } else {
        setError('Unable to load bus routes right now. Please retry.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadInitial();
  }, [loadInitial]);

  useEffect(() => {
    let ws: WebSocket | null = null;
    let reconnectTimer: number | undefined;
    let unmounted = false;
    let attempt = 0;

    const connect = () => {
      if (unmounted) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;

      try {
        ws = new WebSocket(wsUrl);
      } catch {
        setSyncStatus('offline');
        return;
      }

      ws.onopen = () => {
        if (unmounted) return;
        attempt = 0;
        setSyncStatus('live');
      };

      ws.onmessage = (event) => {
        if (unmounted) return;
        try {
          const msg = JSON.parse(event.data) as RealtimeEvent;
          if (msg.type === 'trips:snapshot') {
            setTrips(msg.trips);
            if (routesRef.current.length > 0) {
              saveTimetableCache(routesRef.current, msg.trips);
              setCachedAt(new Date().toISOString());
            }
          } else if (msg.type === 'trip:updated' || msg.type === 'ticket:booked') {
            setTrips((prev) => {
              const next = prev.map((t) => (t.tripId === msg.trip.tripId ? msg.trip : t));
              if (routesRef.current.length > 0) {
                saveTimetableCache(routesRef.current, next);
              }
              return next;
            });
          }
        } catch {
          // Ignore malformed frame
        }
      };

      ws.onclose = () => {
        if (unmounted) return;
        setSyncStatus(navigator.onLine ? 'reconnecting' : 'offline');
        const delay = Math.min(10000, 1000 * Math.pow(1.5, attempt));
        attempt++;
        reconnectTimer = window.setTimeout(connect, delay);
      };

      ws.onerror = () => {
        ws?.close();
      };
    };

    connect();

    const handleOffline = () => setSyncStatus('offline');
    const handleOnline = () => {
      setSyncStatus('reconnecting');
      void loadInitial();
    };

    window.addEventListener('offline', handleOffline);
    window.addEventListener('online', handleOnline);

    return () => {
      unmounted = true;
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('online', handleOnline);
      ws?.close();
    };
  }, [loadInitial]);

  const applyTripUpdate = useCallback((updatedTrip: BusTrip) => {
    setTrips((prev) => {
      const next = prev.map((t) => (t.tripId === updatedTrip.tripId ? updatedTrip : t));
      if (routesRef.current.length > 0) {
        saveTimetableCache(routesRef.current, next);
      }
      return next;
    });
  }, []);

  const applyTripsSnapshot = useCallback((freshTrips: BusTrip[]) => {
    setTrips(freshTrips);
    if (routesRef.current.length > 0) {
      saveTimetableCache(routesRef.current, freshTrips);
    }
  }, []);

  return {
    routes,
    trips,
    loading,
    error,
    syncStatus,
    cachedAt,
    reload: loadInitial,
    applyTripUpdate,
    applyTripsSnapshot,
  };
}
