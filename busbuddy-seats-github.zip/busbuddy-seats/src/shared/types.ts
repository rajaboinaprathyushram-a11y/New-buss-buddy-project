export type UserRole = 'commuter' | 'conductor';

export interface UserPublic {
  id: string;
  name: string;
  identifier: string;
  role: UserRole;
  homeVillage: string;
  studentPassId?: string;
}

export interface LandmarkStop {
  stopId: string;
  villageName: string;
  landmarkName: string;
  stageIndex: number;
  distanceKm: number;
  etaOffsetMins: number;
}

export interface RuralRoute {
  id: string;
  routeNumber: string;
  name: string;
  busType: 'Express Feeder' | 'Palle Velugu' | 'Mandal Shuttle';
  depot: string;
  baseFare: number;
  stageRate: number;
  stops: LandmarkStop[];
}

export type SeatStatus = 'available' | 'occupied' | 'female' | 'female_occupied';

export interface BusSeat {
  id: string;
  number: string;
  row: number;
  col: number;
  side: 'left' | 'right';
  isWindow: boolean;
  isFemaleReserved: boolean;
  status: SeatStatus;
}

export type TripStatus = 'Available' | 'Standing Only' | 'Full';

export type CrowdLevel =
  | 'Seats Plenty'
  | 'Bus is 80% Full'
  | 'Standing Only'
  | 'Bus Full';

export interface CrowdPing {
  level: CrowdLevel;
  reportedAt: string;
  reporterName: string;
  stopName: string;
}

export interface BusTrip {
  tripId: string;
  routeId: string;
  busNumber: string;
  departureTime: string;
  departureInMins: number;
  platformLabel: string;
  totalSeats: number;
  availableSeats: number;
  status: TripStatus;
  seats: BusSeat[];
  crowdPing: CrowdPing | null;
  lastUpdatedAt: string;
  updatedBy: string;
}

export interface TicketPass {
  ticketId: string;
  tripId: string;
  routeNumber: string;
  routeName: string;
  busNumber: string;
  passengerName: string;
  passengerPhone: string;
  boardingVillage: string;
  boardingLandmark: string;
  dropVillage: string;
  dropLandmark: string;
  seatNumbers: string[];
  stages: number;
  baseFare: number;
  stageFare: number;
  studentConcession: boolean;
  studentPassId?: string;
  discountAmount: number;
  farePaid: number;
  upiId: string;
  upiRef: string;
  issuedAt: string;
  departureTime: string;
  userId: string;
}

export type WsServerMessage =
  | { type: 'sync:init'; trips: BusTrip[] }
  | { type: 'trip:updated'; trip: BusTrip }
  | { type: 'demo:reset'; trips: BusTrip[] };
