export interface FareCalculationInput {
  baseFare: number;
  stageRate: number;
  boardingStage: number;
  dropStage: number;
  seatCount: number;
  studentConcession: boolean;
}

export interface FareCalculationResult {
  stages: number;
  baseFarePerSeat: number;
  stageChargePerSeat: number;
  grossTotal: number;
  discountAmount: number;
  finalFare: number;
}

export const STUDENT_CONCESSION_RATE = 0.4;

export function calculateStageFare(input: FareCalculationInput): FareCalculationResult {
  const stages = Math.max(1, Math.abs(input.dropStage - input.boardingStage));
  const seatCount = Math.max(1, input.seatCount);
  const baseFarePerSeat = input.baseFare;
  const stageChargePerSeat = stages * input.stageRate;
  const singleSeatFare = baseFarePerSeat + stageChargePerSeat;
  const grossTotal = singleSeatFare * seatCount;

  const discountAmount = input.studentConcession
    ? Math.round(grossTotal * STUDENT_CONCESSION_RATE)
    : 0;
  const finalFare = Math.max(10, grossTotal - discountAmount);

  return {
    stages,
    baseFarePerSeat,
    stageChargePerSeat,
    grossTotal,
    discountAmount,
    finalFare,
  };
}
