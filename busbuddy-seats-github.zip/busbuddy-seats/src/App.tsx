import { useEffect, useState } from 'react';
import type { BusTrip, TicketPass, UserProfile } from '../shared/transit';
import { ConductorConsoleView } from './components/ConductorConsoleView';
import { LoginPage } from './components/LoginPage';
import { OfflineTimetablesView } from './components/OfflineTimetablesView';
import { RouteFinderView } from './components/RouteFinderView';
import { TicketPassView } from './components/TicketPassView';
import { TopNavbar, type AppView } from './components/TopNavbar';
import { useRealtimeTrips } from './hooks/useRealtimeTrips';
import { fetchMyTickets } from './services/api';
import { loadOfflinePasses, saveOfflinePasses } from './utils/offlineCache';

export default function App() {
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [activeView, setActiveView] = useState<AppView>('finder');

  const [passes, setPasses] = useState<TicketPass[]>([]);
  const [activePassId, setActivePassId] = useState<string | null>(null);

  const {
    routes,
    trips,
    loading,
    error,
    syncStatus,
    cachedAt,
    applyTripUpdate,
    applyTripsSnapshot,
  } = useRealtimeTrips();

  useEffect(() => {
    if (!token || !user) {
      setPasses([]);
      setActivePassId(null);
      return;
    }

    let cancelled = false;
    const cached = loadOfflinePasses(user.id);
    if (cached.length > 0) {
      setPasses(cached);
      setActivePassId(cached[0].ticketId);
    }

    fetchMyTickets(token)
      .then((res) => {
        if (cancelled) return;
        setPasses(res.tickets);
        saveOfflinePasses(user.id, res.tickets);
        if (res.tickets.length > 0) {
          setActivePassId((prev) => prev ?? res.tickets[0].ticketId);
        }
      })
      .catch(() => {
        // Retain cached offline passes when network is unavailable
      });

    return () => {
      cancelled = true;
    };
  }, [token, user]);

  const handleLoginSuccess = (newToken: string, loggedUser: UserProfile) => {
    setToken(newToken);
    setUser(loggedUser);
    setActiveView(loggedUser.role === 'conductor' ? 'conductor' : 'finder');
  };

  const handleLogout = () => {
    setToken(null);
    setUser(null);
    setPasses([]);
    setActivePassId(null);
    setActiveView('finder');
  };

  const handleTicketIssued = (updatedTrip: BusTrip, newTicket: TicketPass) => {
    applyTripUpdate(updatedTrip);
    setPasses((prev) => {
      const next = [newTicket, ...prev.filter((p) => p.ticketId !== newTicket.ticketId)];
      if (user) saveOfflinePasses(user.id, next);
      return next;
    });
    setActivePassId(newTicket.ticketId);
    setActiveView('passes');
  };

  if (!token || !user) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-16 md:pb-8 flex flex-col">
      <TopNavbar
        activeView={activeView}
        onNavigate={setActiveView}
        user={user}
        onLogout={handleLogout}
      />

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6">
        {activeView === 'finder' && (
          <RouteFinderView
            routes={routes}
            trips={trips}
            loading={loading}
            error={error}
            syncStatus={syncStatus}
            user={user}
            token={token}
            onTripUpdated={applyTripUpdate}
            onTicketIssued={handleTicketIssued}
          />
        )}

        {activeView === 'conductor' && (
          <ConductorConsoleView
            routes={routes}
            trips={trips}
            user={user}
            token={token}
            onTripUpdated={applyTripUpdate}
            onTripsSnapshot={applyTripsSnapshot}
            onRoleSwitchLogin={(newToken, switchedUser) => {
              setToken(newToken);
              setUser(switchedUser);
            }}
          />
        )}

        {activeView === 'passes' && (
          <TicketPassView
            passes={passes}
            activePassId={activePassId}
            onSelectPass={setActivePassId}
            onBackToFinder={() => setActiveView('finder')}
          />
        )}

        {activeView === 'timetables' && (
          <OfflineTimetablesView
            routes={routes}
            trips={trips}
            cachedAt={cachedAt}
          />
        )}
      </main>

      <footer className="no-print border-t border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2 px-4 py-3 text-xs text-slate-500 sm:px-6">
          <span>BusBuddy Seats: VillageRoute Rush</span>
          <span>Rural RTC Schedule &amp; Live Seat Availability System</span>
        </div>
      </footer>
    </div>
  );
}
