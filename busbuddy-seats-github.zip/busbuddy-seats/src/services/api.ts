import type {
  BusTrip,
  CrowdLevel,
  RuralRoute,
  TicketPass,
  UserProfile,
} from '../../shared/transit';

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function requestJson<T>(
  url: string,
  options: RequestInit = {},
  token?: string | null
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) || {}),
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const response = await fetch(url, { ...options, headers });
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const message = typeof data?.error === 'string' ? data.error : `Request failed (${response.status})`;
    throw new ApiError(message, response.status);
  }

  return data as T;
}

export async function loginAccount(
  identifier: string,
  password: string
): Promise<{ token: string; user: UserProfile }> {
  return requestJson('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ identifier, password }),
  });
}

export async function registerCommuter(payload: {
  name: string;
  identifier: string;
  password: string;
  depotOrVillage: string;
}): Promise<{ token: string; user: UserProfile }> {
  return requestJson('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function fetchRoutesAndTrips(): Promise<{
  routes: RuralRoute[];
  trips: BusTrip[];
}> {
  return requestJson('/api/trips');
}

export async function updateConductorSeats(
  token: string,
  tripId: string,
  payload: { delta?: number; mode?: 'standing' | 'full' }
): Promise<{ trip: BusTrip }> {
  return requestJson(
    `/api/trips/${encodeURIComponent(tripId)}/seats`,
    {
      method: 'POST',
      body: JSON.stringify(payload),
    },
    token
  );
}

export async function resetDemoTrips(token: string): Promise<{ trips: BusTrip[] }> {
  return requestJson('/api/trips/reset-demo', { method: 'POST' }, token);
}

export async function sendCrowdPing(
  token: string,
  tripId: string,
  level: CrowdLevel,
  stopName: string
): Promise<{ trip: BusTrip }> {
  return requestJson(
    `/api/trips/${encodeURIComponent(tripId)}/crowd-ping`,
    {
      method: 'POST',
      body: JSON.stringify({ level, stopName }),
    },
    token
  );
}

export async function fetchMyTickets(token: string): Promise<{ tickets: TicketPass[] }> {
  return requestJson('/api/tickets', { method: 'GET' }, token);
}

export async function createTicketBooking(
  token: string,
  payload: {
    tripId: string;
    passengerName: string;
    passengerPhone: string;
    boardingStopId: string;
    dropStopId: string;
    seatNumbers: string[];
    studentConcession: boolean;
    studentPassId?: string;
    upiRef: string;
  }
): Promise<{ trip: BusTrip; ticket: TicketPass }> {
  return requestJson(
    '/api/tickets',
    {
      method: 'POST',
      body: JSON.stringify(payload),
    },
    token
  );
}
