import type { BusTrip, RuralRoute } from '../../shared/transit';

export type AnnouncementLanguage = 'en-IN' | 'te-IN' | 'hi-IN';

export function buildAnnouncementText(
  lang: AnnouncementLanguage,
  route: RuralRoute,
  trip: BusTrip
): string {
  const firstStop = route.stops[0];
  const lastStop = route.stops[route.stops.length - 1];
  const seatsPhrase =
    trip.availableSeats > 0
      ? `${trip.availableSeats} seats available`
      : trip.status === 'Standing Only'
      ? 'standing passengers only'
      : 'bus is currently full';

  if (lang === 'te-IN') {
    const teSeats =
      trip.availableSeats > 0
        ? `${trip.availableSeats} సీట్లు ఖాళీగా ఉన్నాయి`
        : trip.status === 'Standing Only'
        ? 'నిలబడి ప్రయాణించడానికి మాత్రమే అవకాశం ఉంది'
        : 'బస్సు పూర్తిగా నిండింది';
    return `దయచేసి వినండి. బస్సు నంబర్ ${route.routeNumber}, ${firstStop.villageName} నుండి ${lastStop.villageName} వెళ్ళే బస్సు ${trip.departureInMins} నిమిషాల్లో ${firstStop.landmarkName} వద్దకు వస్తుంది. ప్రస్తుతం ${teSeats}.`;
  }

  if (lang === 'hi-IN') {
    const hiSeats =
      trip.availableSeats > 0
        ? `${trip.availableSeats} सीटें खाली हैं`
        : trip.status === 'Standing Only'
        ? 'केवल खड़े होने की जगह है'
        : 'बस पूरी भरी हुई है';
    return `यात्री ध्यान दें। बस नंबर ${route.routeNumber}, ${firstStop.villageName} से ${lastStop.villageName} जाने वाली बस ${trip.departureInMins} मिनट में ${firstStop.landmarkName} से रवाना होगी। अभी ${hiSeats}।`;
  }

  return `Attention commuters. Route ${route.routeNumber} from ${firstStop.villageName} to ${lastStop.villageName} departs in ${trip.departureInMins} minutes from ${firstStop.landmarkName}. Currently ${seatsPhrase}.`;
}

export function speakBusAnnouncement(
  lang: AnnouncementLanguage,
  route: RuralRoute,
  trip: BusTrip
): { supported: boolean; spokenText: string } {
  const text = buildAnnouncementText(lang, route, trip);

  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return { supported: false, spokenText: text };
  }

  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = 0.95;

    const voices = window.speechSynthesis.getVoices();
    const matchingVoice = voices.find((v) => v.lang.toLowerCase().startsWith(lang.slice(0, 2).toLowerCase()));
    if (matchingVoice) {
      utterance.voice = matchingVoice;
    }

    window.speechSynthesis.speak(utterance);
    return { supported: true, spokenText: text };
  } catch {
    return { supported: false, spokenText: text };
  }
}

export function stopAnnouncement(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}
