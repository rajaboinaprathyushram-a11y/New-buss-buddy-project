import type { BusTrip, RuralRoute, TicketPass } from '../../shared/transit';

const TIMETABLE_CACHE_KEY = 'busbuddy_rural_timetable_v1';
const TICKETS_CACHE_KEY = 'busbuddy_offline_passes_v1';

export interface CachedTimetablePayload {
  routes: RuralRoute[];
  trips: BusTrip[];
  cachedAt: string;
}

export function saveTimetableCache(routes: RuralRoute[], trips: BusTrip[]): void {
  try {
    const payload: CachedTimetablePayload = {
      routes,
      trips,
      cachedAt: new Date().toISOString(),
    };
    localStorage.setItem(TIMETABLE_CACHE_KEY, JSON.stringify(payload));
  } catch {
    // Ignore storage quota errors on constrained feature browsers
  }
}

export function loadTimetableCache(): CachedTimetablePayload | null {
  try {
    const raw = localStorage.getItem(TIMETABLE_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as CachedTimetablePayload;
    if (!Array.isArray(parsed.routes) || !Array.isArray(parsed.trips)) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveOfflinePasses(userId: string, passes: TicketPass[]): void {
  try {
    const raw = localStorage.getItem(TICKETS_CACHE_KEY);
    const map: Record<string, TicketPass[]> = raw ? JSON.parse(raw) : {};
    map[userId] = passes;
    localStorage.setItem(TICKETS_CACHE_KEY, JSON.stringify(map));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadOfflinePasses(userId: string): TicketPass[] {
  try {
    const raw = localStorage.getItem(TICKETS_CACHE_KEY);
    if (!raw) return [];
    const map = JSON.parse(raw) as Record<string, TicketPass[]>;
    return Array.isArray(map[userId]) ? map[userId] : [];
  } catch {
    return [];
  }
}
