import type { TicketPass } from '../../shared/transit';

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function downloadBoardingPassHtml(ticket: TicketPass, qrDataUrl: string): void {
  const safeQr = qrDataUrl.startsWith('data:image/') ? qrDataUrl : '';
  const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Boarding Pass ${escapeHtml(ticket.ticketId)}</title>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; background: #f8fafc; color: #0f172a; padding: 24px; }
    .pass { max-width: 560px; margin: 0 auto; background: #fff; border: 2px solid #0f172a; border-radius: 8px; padding: 24px; }
    .header { display: flex; justify-content: space-between; border-bottom: 1px solid #cbd5e1; padding-bottom: 12px; margin-bottom: 16px; }
    .title { font-size: 18px; font-weight: 700; margin: 0; }
    .sub { font-size: 12px; color: #475569; margin: 2px 0 0; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px; }
    .label { font-size: 11px; color: #64748b; text-transform: uppercase; letter-spacing: 0.04em; }
    .val { font-size: 14px; font-weight: 600; margin-top: 2px; }
    .footer { display: flex; align-items: center; justify-content: space-between; border-top: 1px dashed #94a3b8; padding-top: 16px; }
    .fare { font-size: 22px; font-weight: 700; }
  </style>
</head>
<body>
  <div class="pass">
    <div class="header">
      <div>
        <p class="title">BusBuddy Seats · Rural RTC E-Pass</p>
        <p class="sub">Route #${escapeHtml(ticket.routeNumber)} — ${escapeHtml(ticket.routeName)}</p>
      </div>
      <div style="text-align:right">
        <div class="label">Ticket ID</div>
        <div class="val">${escapeHtml(ticket.ticketId)}</div>
      </div>
    </div>
    <div class="grid">
      <div><div class="label">Passenger</div><div class="val">${escapeHtml(ticket.passengerName)}</div></div>
      <div><div class="label">Mobile</div><div class="val">${escapeHtml(ticket.passengerPhone)}</div></div>
      <div><div class="label">Boarding Landmark</div><div class="val">${escapeHtml(ticket.boardingVillage)} (${escapeHtml(ticket.boardingLandmark)})</div></div>
      <div><div class="label">Drop Stop</div><div class="val">${escapeHtml(ticket.dropVillage)} (${escapeHtml(ticket.dropLandmark)})</div></div>
      <div><div class="label">Seats</div><div class="val">${escapeHtml(ticket.seatNumbers.join(', '))}</div></div>
      <div><div class="label">Bus & Departure</div><div class="val">${escapeHtml(ticket.busRegistration)} · ${escapeHtml(ticket.departureTime)}</div></div>
      <div><div class="label">UPI Reference</div><div class="val">${escapeHtml(ticket.upiRef)}</div></div>
      <div><div class="label">Concession</div><div class="val">${ticket.studentConcession ? `Student Pass (${escapeHtml(ticket.studentPassId || 'Verified')})` : 'Standard Adult Fare'}</div></div>
    </div>
    <div class="footer">
      <div>
        <div class="label">Total Paid (Stages: ${ticket.stages})</div>
        <div class="fare">INR ${ticket.farePaid}</div>
      </div>
      ${safeQr ? `<img src="${safeQr}" alt="Ticket QR" width="88" height="88" />` : ''}
    </div>
  </div>
</body>
</html>`;

  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `BusBuddy-Pass-${ticket.ticketId}.html`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function downloadBoardingPassText(ticket: TicketPass): void {
  const lines = [
    '========================================',
    '  BUSBUDDY SEATS - RURAL RTC PASS',
    '========================================',
    `Ticket ID     : ${ticket.ticketId}`,
    `Route         : #${ticket.routeNumber} (${ticket.routeName})`,
    `Bus Reg       : ${ticket.busRegistration}`,
    `Departure     : ${ticket.departureTime}`,
    `Passenger     : ${ticket.passengerName} (${ticket.passengerPhone})`,
    `Boarding      : ${ticket.boardingVillage} - ${ticket.boardingLandmark}`,
    `Drop Stop     : ${ticket.dropVillage} - ${ticket.dropLandmark}`,
    `Seats         : ${ticket.seatNumbers.join(', ')}`,
    `Stages        : ${ticket.stages}`,
    `Concession    : ${ticket.studentConcession ? `Student (${ticket.studentPassId})` : 'None'}`,
    `Fare Paid     : Rs. ${ticket.farePaid}`,
    `UPI Ref       : ${ticket.upiRef}`,
    `Issued At     : ${new Date(ticket.issuedAt).toLocaleString()}`,
    '========================================',
  ].join('\n');

  const blob = new Blob([lines], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `BusBuddy-Pass-${ticket.ticketId}.txt`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
