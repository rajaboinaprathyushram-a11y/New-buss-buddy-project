import { useState, type FormEvent } from 'react';
import { Bus, KeyRound, ShieldCheck, UserPlus } from 'lucide-react';
import type { UserProfile } from '../../shared/transit';
import { loginAccount, registerCommuter } from '../services/api';

interface LoginPageProps {
  onLoginSuccess: (token: string, user: UserProfile) => void;
}

export function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [village, setVillage] = useState('Narsapur');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!identifier.trim() || !password) {
      setError('Please enter your email or mobile number and password.');
      return;
    }

    if (mode === 'register' && name.trim().length < 2) {
      setError('Please enter your full name.');
      return;
    }

    setSubmitting(true);
    try {
      if (mode === 'login') {
        const res = await loginAccount(identifier.trim(), password);
        onLoginSuccess(res.token, res.user);
      } else {
        const res = await registerCommuter({
          name: name.trim(),
          identifier: identifier.trim(),
          password,
          depotOrVillage: village.trim() || 'Narsapur',
        });
        onLoginSuccess(res.token, res.user);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to sign in right now.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDemoLogin = async (role: 'commuter' | 'conductor') => {
    setError(null);
    const demoId = role === 'commuter' ? 'ravi.narsapur@rtc-demo.in' : 'venkat.312@rtc-demo.in';
    const demoPw = role === 'commuter' ? 'commuter123' : 'conductor123';
    setMode('login');
    setIdentifier(demoId);
    setPassword(demoPw);
    setSubmitting(true);
    try {
      const res = await loginAccount(demoId, demoPw);
      onLoginSuccess(res.token, res.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Demo login failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-2.5 text-lg font-bold tracking-tight text-slate-900">
            <Bus className="h-5 w-5 text-blue-800" aria-hidden="true" />
            <span>BusBuddy Seats</span>
          </div>
          <span className="text-xs font-medium text-slate-500">
            Rural State Transport Portal
          </span>
        </div>
      </header>

      <main className="mx-auto grid w-full max-w-6xl flex-1 grid-cols-1 items-center gap-10 px-4 py-10 sm:px-6 lg:grid-cols-12">
        <section className="lg:col-span-6 space-y-6">
          <div className="space-y-3">
            <p className="text-xs font-semibold tracking-wide text-blue-800 uppercase">
              VillageRoute Rush · Medak &amp; Sangareddy Sector
            </p>
            <h1 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl [text-wrap:balance]">
              Live Rural RTC Bus Schedules &amp; Seat Availability
            </h1>
            <p className="max-w-xl text-base leading-relaxed text-slate-600">
              Check real-time vacant seat counts updated directly by bus conductors, locate
              village landmark boarding points, and generate printable UPI QR boarding passes.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 border-t border-slate-200 pt-6 sm:grid-cols-3">
            <div>
              <p className="font-mono text-2xl font-bold text-slate-900 tabular-nums">10</p>
              <p className="text-xs text-slate-600">Rural Feeder Routes</p>
            </div>
            <div>
              <p className="font-mono text-2xl font-bold text-slate-900 tabular-nums">25</p>
              <p className="text-xs text-slate-600">Village Landmark Stops</p>
            </div>
            <div>
              <p className="font-mono text-2xl font-bold text-slate-900 tabular-nums">₹15–₹65</p>
              <p className="text-xs text-slate-600">Stage Fare &amp; Student Pass</p>
            </div>
          </div>

          <div className="rounded-lg border border-slate-200 bg-white p-4 text-sm text-slate-600 space-y-1.5">
            <p className="font-semibold text-slate-900">Quick Demo Access</p>
            <p className="text-xs leading-relaxed text-slate-600">
              Use the Student account to search Narsapur to Medak Town (Route #312), inspect the
              2x3 seat map, and pay via UPI QR. Use the Conductor account in another tab to tap{' '}
              <span className="font-mono font-semibold text-slate-900">-3</span> and watch seats
              update live.
            </p>
          </div>
        </section>

        <section className="lg:col-span-6">
          <div className="mx-auto max-w-md rounded-lg border border-slate-200 bg-white p-6 sm:p-8">
            <div className="mb-6 flex border-b border-slate-200">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError(null);
                }}
                className={`flex-1 border-b-2 pb-3 text-sm font-semibold transition-colors ${
                  mode === 'login'
                    ? 'border-blue-800 text-slate-900'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setError(null);
                }}
                className={`flex-1 border-b-2 pb-3 text-sm font-semibold transition-colors ${
                  mode === 'register'
                    ? 'border-blue-800 text-slate-900'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                New Commuter Sign Up
              </button>
            </div>

            {error && (
              <div
                role="alert"
                className="mb-4 rounded-md border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-800"
              >
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'register' && (
                <>
                  <div>
                    <label
                      htmlFor="reg-name"
                      className="mb-1.5 block text-xs font-semibold text-slate-700"
                    >
                      Full Name
                    </label>
                    <input
                      id="reg-name"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g., Sai Kiran Reddy"
                      className="w-full rounded-md border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-700 focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="reg-village"
                      className="mb-1.5 block text-xs font-semibold text-slate-700"
                    >
                      Home Village / Mandal
                    </label>
                    <input
                      id="reg-village"
                      type="text"
                      value={village}
                      onChange={(e) => setVillage(e.target.value)}
                      placeholder="e.g., Narsapur"
                      className="w-full rounded-md border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-700 focus:outline-none"
                    />
                  </div>
                </>
              )}

              <div>
                <label
                  htmlFor="auth-identifier"
                  className="mb-1.5 block text-xs font-semibold text-slate-700"
                >
                  Email or Mobile ID
                </label>
                <input
                  id="auth-identifier"
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="ravi.narsapur@rtc-demo.in"
                  autoComplete="username"
                  className="w-full rounded-md border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-700 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label
                  htmlFor="auth-password"
                  className="mb-1.5 block text-xs font-semibold text-slate-700"
                >
                  Password
                </label>
                <input
                  id="auth-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  className="w-full rounded-md border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-700 focus:outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-md bg-blue-800 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-900 disabled:opacity-60"
              >
                {mode === 'login' ? (
                  <>
                    <KeyRound className="h-4 w-4" aria-hidden="true" />
                    <span>{submitting ? 'Signing In...' : 'Sign In to Portal'}</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="h-4 w-4" aria-hidden="true" />
                    <span>{submitting ? 'Creating Account...' : 'Create Commuter Account'}</span>
                  </>
                )}
              </button>
            </form>

            <div className="mt-6 border-t border-slate-200 pt-5 space-y-2.5">
              <p className="text-xs font-semibold text-slate-700">
                One-Click Demo Credentials
              </p>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => void handleDemoLogin('commuter')}
                  className="flex min-h-[44px] flex-col items-start justify-center rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-left transition-colors hover:bg-slate-100 disabled:opacity-60"
                >
                  <span className="text-xs font-semibold text-slate-900">
                    Demo Student (Commuter)
                  </span>
                  <span className="font-mono text-[11px] text-slate-500">
                    ravi.narsapur@rtc-demo.in
                  </span>
                </button>
                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => void handleDemoLogin('conductor')}
                  className="flex min-h-[44px] flex-col items-start justify-center rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-left transition-colors hover:bg-slate-100 disabled:opacity-60"
                >
                  <span className="flex items-center gap-1 text-xs font-semibold text-slate-900">
                    <ShieldCheck className="h-3.5 w-3.5 text-emerald-700" aria-hidden="true" />
                    Demo Conductor (#312)
                  </span>
                  <span className="font-mono text-[11px] text-slate-500">
                    venkat.312@rtc-demo.in
                  </span>
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 py-3 text-xs text-slate-500 sm:px-6">
          <span>BusBuddy Seats · Rural RTC Transit Utility</span>
          <span>Offline timetable caching enabled via browser storage</span>
        </div>
      </footer>
    </div>
  );
}
