import QRCode from 'qrcode';
import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { ArrowLeft, CheckCircle2, QrCode, Ticket } from 'lucide-react';
import { calculateStageFare } from '../../shared/fare';
import type { BusTrip, RuralRoute, TicketPass, UserProfile } from '../../shared/transit';
import { createTicketBooking } from '../services/api';

interface CheckoutPanelProps {
  route: RuralRoute;
  trip: BusTrip;
  selectedSeats: string[];
  user: UserProfile;
  token: string;
  preferredOrigin?: string;
  preferredDestination?: string;
  onTicketIssued: (trip: BusTrip, ticket: TicketPass) => void;
}

export function CheckoutPanel({
  route,
  trip,
  selectedSeats,
  user,
  token,
  preferredOrigin,
  preferredDestination,
  onTicketIssued,
}: CheckoutPanelProps) {
  const [boardingStopId, setBoardingStopId] = useState(route.stops[0].stopId);
  const [dropStopId, setDropStopId] = useState(route.stops[route.stops.length - 1].stopId);
  const [studentConcession, setStudentConcession] = useState(false);
  const [studentPassId, setStudentPassId] = useState('');

  const [passengerName, setPassengerName] = useState(user.name.replace(/\s*\(.*\)$/, ''));
  const [passengerPhone, setPassengerPhone] = useState('9848012345');

  const [step, setStep] = useState<'details' | 'qr'>('details');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [upiRef, setUpiRef] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Sync default stops when switching routes or village filters
  useEffect(() => {
    const matchedBoarding = preferredOrigin
      ? route.stops.slice(0, -1).find((s) => s.villageName === preferredOrigin)
      : undefined;
    const nextBoarding = matchedBoarding ?? route.stops[0];

    const matchedDrop = preferredDestination
      ? route.stops.find(
          (s) =>
            s.villageName === preferredDestination &&
            s.stageIndex > nextBoarding.stageIndex
        )
      : undefined;
    const nextDrop = matchedDrop ?? route.stops[route.stops.length - 1];

    setBoardingStopId(nextBoarding.stopId);
    setDropStopId(nextDrop.stopId);
    setStep('details');
    setFormError(null);
  }, [route.id, route.stops, preferredOrigin, preferredDestination]);

  const boardingStop = useMemo(
    () => route.stops.find((s) => s.stopId === boardingStopId) ?? route.stops[0],
    [route.stops, boardingStopId]
  );

  const dropOptions = useMemo(
    () => route.stops.filter((s) => s.stageIndex > boardingStop.stageIndex),
    [route.stops, boardingStop.stageIndex]
  );

  const dropStop = useMemo(() => {
    const found = dropOptions.find((s) => s.stopId === dropStopId);
    return found ?? dropOptions[dropOptions.length - 1] ?? route.stops[route.stops.length - 1];
  }, [dropOptions, dropStopId, route.stops]);

  useEffect(() => {
    if (dropStop && dropStop.stopId !== dropStopId) {
      setDropStopId(dropStop.stopId);
    }
  }, [dropStop, dropStopId]);

  const fare = useMemo(() => {
    const count = Math.max(1, selectedSeats.length);
    return calculateStageFare(route, boardingStop, dropStop, count, studentConcession);
  }, [route, boardingStop, dropStop, selectedSeats.length, studentConcession]);

  const upiUri = useMemo(() => {
    const note = `RTC Route ${route.routeNumber} ${boardingStop.villageName} to ${dropStop.villageName}`;
    return `upi://pay?pa=ruralrtc.medak@upi&pn=BusBuddy%20Rural%20RTC&am=${fare.finalFare}&cu=INR&tn=${encodeURIComponent(note)}`;
  }, [route.routeNumber, boardingStop.villageName, dropStop.villageName, fare.finalFare]);

  useEffect(() => {
    if (step !== 'qr') return;
    let cancelled = false;
    QRCode.toDataURL(upiUri, {
      width: 240,
      margin: 2,
      color: { dark: '#0f172a', light: '#ffffff' },
    })
      .then((url) => {
        if (!cancelled) setQrDataUrl(url);
      })
      .catch(() => {
        if (!cancelled) setQrDataUrl('');
      });
    return () => {
      cancelled = true;
    };
  }, [step, upiUri]);

  const handleProceedToQr = (e: FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (selectedSeats.length === 0) {
      setFormError('Select at least one available seat from the 2×3 bus seat map first.');
      return;
    }
    if (passengerName.trim().length < 2) {
      setFormError('Enter the passenger full name.');
      return;
    }
    if (!/^[6-9]\d{9}$/.test(passengerPhone.trim())) {
      setFormError('Enter a valid 10-digit mobile number starting with 6, 7, 8, or 9.');
      return;
    }
    if (studentConcession && studentPassId.trim().length < 4) {
      setFormError('Enter your Student Bus Pass ID (minimum 4 characters).');
      return;
    }

    const generatedDemoUtr = `UPI${Date.now().toString().slice(-8)}`;
    setUpiRef(generatedDemoUtr);
    setStep('qr');
  };

  const handleConfirmPayment = async () => {
    setFormError(null);
    const cleanedUtr = upiRef.trim();
    if (cleanedUtr.length < 6) {
      setFormError('Enter a valid 6+ character UPI Transaction / UTR Reference.');
      return;
    }

    setSubmitting(true);
    try {
      const result = await createTicketBooking(token, {
        tripId: trip.tripId,
        passengerName: passengerName.trim(),
        passengerPhone: passengerPhone.trim(),
        boardingStopId: boardingStop.stopId,
        dropStopId: dropStop.stopId,
        seatNumbers: selectedSeats,
        studentConcession,
        studentPassId: studentConcession ? studentPassId.trim() : undefined,
        upiRef: cleanedUtr,
      });
      onTicketIssued(result.trip, result.ticket);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Payment verification failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div>
          <h3 className="text-base font-bold text-slate-900">
            {step === 'details'
              ? 'Stage Fare & Passenger Details'
              : 'Scan UPI QR Code & Confirm Payment'}
          </h3>
          <p className="text-xs text-slate-500">
            Route #{route.routeNumber} · {boardingStop.villageName} to {dropStop.villageName}
          </p>
        </div>
        <div className="text-right">
          <p className="text-[11px] font-medium text-slate-500">Total Fare</p>
          <p className="font-mono text-xl font-bold text-slate-900 tabular-nums">
            ₹{fare.finalFare}
          </p>
        </div>
      </div>

      {formError && (
        <div
          role="alert"
          className="rounded-md border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-800"
        >
          {formError}
        </div>
      )}

      {step === 'details' ? (
        <form onSubmit={handleProceedToQr} className="space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label
                htmlFor="boarding-stop"
                className="mb-1 block text-xs font-semibold text-slate-700"
              >
                Boarding Landmark Stop
              </label>
              <select
                id="boarding-stop"
                value={boardingStop.stopId}
                onChange={(e) => setBoardingStopId(e.target.value)}
                className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-700 focus:outline-none"
              >
                {route.stops.slice(0, -1).map((stop) => (
                  <option key={stop.stopId} value={stop.stopId}>
                    {stop.villageName} — {stop.landmarkName}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="drop-stop"
                className="mb-1 block text-xs font-semibold text-slate-700"
              >
                Drop Stop
              </label>
              <select
                id="drop-stop"
                value={dropStop.stopId}
                onChange={(e) => setDropStopId(e.target.value)}
                className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-700 focus:outline-none"
              >
                {dropOptions.map((stop) => (
                  <option key={stop.stopId} value={stop.stopId}>
                    {stop.villageName} — {stop.landmarkName}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label
                htmlFor="pax-name"
                className="mb-1 block text-xs font-semibold text-slate-700"
              >
                Passenger Full Name
              </label>
              <input
                id="pax-name"
                type="text"
                value={passengerName}
                onChange={(e) => setPassengerName(e.target.value)}
                placeholder="Enter full name"
                className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-700 focus:outline-none"
                required
              />
            </div>

            <div>
              <label
                htmlFor="pax-phone"
                className="mb-1 block text-xs font-semibold text-slate-700"
              >
                Mobile Number (10 Digits)
              </label>
              <input
                id="pax-phone"
                type="tel"
                maxLength={10}
                value={passengerPhone}
                onChange={(e) => setPassengerPhone(e.target.value.replace(/\D/g, ''))}
                placeholder="9848012345"
                className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:border-blue-700 focus:outline-none"
                required
              />
            </div>
          </div>

          <div className="rounded-md border border-slate-200 bg-slate-50 p-3.5 space-y-3">
            <label className="flex cursor-pointer items-center gap-2.5 text-sm font-medium text-slate-800">
              <input
                type="checkbox"
                checked={studentConcession}
                onChange={(e) => setStudentConcession(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-blue-800 focus:ring-blue-700"
              />
              <span>Apply Student Bus Pass Concession (40% off 1st seat)</span>
            </label>

            {studentConcession && (
              <div>
                <label
                  htmlFor="student-pass-id"
                  className="mb-1 block text-xs font-semibold text-slate-700"
                >
                  Student Bus Pass ID
                </label>
                <input
                  id="student-pass-id"
                  type="text"
                  value={studentPassId}
                  onChange={(e) => setStudentPassId(e.target.value)}
                  placeholder="e.g., TS-MDK-STU-4021"
                  className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:border-blue-700 focus:outline-none"
                />
              </div>
            )}
          </div>

          {/* Stage-Based Fare Formula Breakdown */}
          <div className="rounded-md border border-slate-200 bg-white p-3.5 text-xs text-slate-600 space-y-1.5">
            <div className="flex justify-between">
              <span>
                Base Fare + ({fare.stages} {fare.stages === 1 ? 'Stage' : 'Stages'} × ₹
                {fare.stageRate})
              </span>
              <span className="font-mono font-semibold text-slate-900 tabular-nums">
                ₹{fare.singleSeatGross} / seat
              </span>
            </div>
            <div className="flex justify-between">
              <span>
                Selected Seats ({selectedSeats.length > 0 ? selectedSeats.join(', ') : 'None'})
              </span>
              <span className="font-mono text-slate-900 tabular-nums">
                {selectedSeats.length} × ₹{fare.singleSeatGross} = ₹{fare.grossFare}
              </span>
            </div>
            {fare.studentConcessionApplied && (
              <div className="flex justify-between text-emerald-700 font-medium">
                <span>Student Pass Concession</span>
                <span className="font-mono tabular-nums">-₹{fare.discountAmount}</span>
              </div>
            )}
            <div className="flex justify-between border-t border-slate-200 pt-1.5 text-sm font-bold text-slate-900">
              <span>Payable via UPI QR</span>
              <span className="font-mono tabular-nums">₹{fare.finalFare}</span>
            </div>
          </div>

          <button
            type="submit"
            disabled={selectedSeats.length === 0}
            className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-md bg-blue-800 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-900 disabled:cursor-not-allowed disabled:bg-slate-300 disabled:text-slate-600"
          >
            <QrCode className="h-4 w-4" aria-hidden="true" />
            <span>
              {selectedSeats.length === 0
                ? 'Select Seat(s) on 2×3 Layout to Pay'
                : `Proceed to UPI QR Payment (₹${fare.finalFare})`}
            </span>
          </button>
        </form>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 rounded-lg border border-slate-200 bg-slate-50 p-4 sm:grid-cols-12 sm:items-center">
            <div className="sm:col-span-5 flex flex-col items-center justify-center rounded-md border border-slate-200 bg-white p-3">
              {qrDataUrl ? (
                <img
                  src={qrDataUrl}
                  alt={`UPI QR code for paying ₹${fare.finalFare} to BusBuddy Rural RTC`}
                  className="h-44 w-44 object-contain"
                />
              ) : (
                <div className="flex h-44 w-44 items-center justify-center text-xs text-slate-500">
                  Generating QR...
                </div>
              )}
              <span className="mt-2 font-mono text-[11px] font-semibold text-slate-700">
                ruralrtc.medak@upi
              </span>
            </div>

            <div className="sm:col-span-7 space-y-2.5 text-xs text-slate-700">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                  Merchant &amp; Passenger Summary
                </p>
                <p className="mt-1 font-semibold text-slate-900">
                  BusBuddy Rural RTC · Medak Depot
                </p>
              </div>
              <div className="space-y-1 border-t border-slate-200 pt-2">
                <p>
                  <span className="text-slate-500">Passenger:</span>{' '}
                  <span className="font-semibold text-slate-900">{passengerName}</span> (
                  <span className="font-mono">{passengerPhone}</span>)
                </p>
                <p>
                  <span className="text-slate-500">Boarding:</span>{' '}
                  <span className="font-semibold text-slate-900">
                    {boardingStop.villageName} · {boardingStop.landmarkName}
                  </span>
                </p>
                <p>
                  <span className="text-slate-500">Drop:</span>{' '}
                  <span className="font-semibold text-slate-900">{dropStop.villageName}</span>
                </p>
                <p>
                  <span className="text-slate-500">Seats:</span>{' '}
                  <span className="font-mono font-bold text-blue-900">
                    {selectedSeats.join(', ')}
                  </span>
                </p>
                <p>
                  <span className="text-slate-500">Amount Due:</span>{' '}
                  <span className="font-mono text-sm font-bold text-emerald-800">
                    ₹{fare.finalFare}
                  </span>
                </p>
              </div>

              <div className="pt-1">
                <label
                  htmlFor="upi-utr"
                  className="mb-1 block text-[11px] font-semibold text-slate-700"
                >
                  UPI Transaction / UTR Reference (Auto-filled for Demo)
                </label>
                <input
                  id="upi-utr"
                  type="text"
                  value={upiRef}
                  onChange={(e) => setUpiRef(e.target.value)}
                  className="w-full rounded-md border border-slate-300 bg-white px-2.5 py-2 font-mono text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => setStep('details')}
              className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              <span>Edit Details</span>
            </button>

            <button
              type="button"
              disabled={submitting}
              onClick={() => void handleConfirmPayment()}
              className="flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-md bg-emerald-700 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-emerald-800 disabled:opacity-60"
            >
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              <span>
                {submitting
                  ? 'Confirming Payment...'
                  : `Verify Payment & Issue Digital Pass (₹${fare.finalFare})`}
              </span>
            </button>
          </div>
          <p className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <Ticket className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
            <span>
              Confirming payment immediately reserves seat(s) {selectedSeats.join(', ')} and
              generates an offline-printable boarding voucher.
            </span>
          </p>
        </div>
      )}
    </div>
  );
}
