import { useEffect, useMemo, useState } from 'react';
import {
  MapPin,
  Search,
  Users,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
} from 'lucide-react';
import type {
  BusTrip,
  CrowdLevel,
  RuralRoute,
  TicketPass,
  UserProfile,
} from '../../shared/transit';
import type { SyncStatus } from '../hooks/useRealtimeTrips';
import { sendCrowdPing } from '../services/api';
import {
  speakBusAnnouncement,
  stopAnnouncement,
  type AnnouncementLanguage,
} from '../utils/speechAnnouncer';
import { BusSeatLayout } from './BusSeatLayout';
import { CheckoutPanel } from './CheckoutPanel';

interface RouteFinderViewProps {
  routes: RuralRoute[];
  trips: BusTrip[];
  loading: boolean;
  error: string | null;
  syncStatus: SyncStatus;
  user: UserProfile;
  token: string;
  onTripUpdated: (trip: BusTrip) => void;
  onTicketIssued: (trip: BusTrip, ticket: TicketPass) => void;
}

const CROWD_OPTIONS: CrowdLevel[] = [
  'Seats Plenty',
  'Bus is 80% Full',
  'Standing Only',
  'Bus Full',
];

export function RouteFinderView({
  routes,
  trips,
  loading,
  error,
  syncStatus,
  user,
  token,
  onTripUpdated,
  onTicketIssued,
}: RouteFinderViewProps) {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [keyword, setKeyword] = useState('');
  const [selectedTripId, setSelectedTripId] = useState<string>('TRIP-312-A');
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);

  const [announcementText, setAnnouncementText] = useState<string | null>(null);
  const [announcementTripId, setAnnouncementTripId] = useState<string | null>(null);
  const [pingFeedback, setPingFeedback] = useState<string | null>(null);
  const [pingLoadingId, setPingLoadingId] = useState<string | null>(null);

  const allVillages = useMemo(() => {
    const names = new Set<string>();
    for (const r of routes) {
      for (const s of r.stops) {
        names.add(s.villageName);
      }
    }
    return Array.from(names).sort((a, b) => a.localeCompare(b));
  }, [routes]);

  const routeMap = useMemo(() => {
    const map = new Map<string, RuralRoute>();
    for (const r of routes) map.set(r.id, r);
    return map;
  }, [routes]);

  const { filteredTrips, matchType } = useMemo(() => {
    const kw = keyword.trim().toLowerCase();
    const keywordMatched = trips.filter((trip) => {
      const route = routeMap.get(trip.routeId);
      if (!route) return false;
      if (!kw) return true;

      const matchesRoute =
        route.routeNumber.toLowerCase().includes(kw) ||
        route.name.toLowerCase().includes(kw) ||
        trip.busRegistration.toLowerCase().includes(kw);
      const matchesStop = route.stops.some(
        (s) =>
          s.villageName.toLowerCase().includes(kw) ||
          s.landmarkName.toLowerCase().includes(kw)
      );
      return matchesRoute || matchesStop;
    });

    if (origin && destination) {
      const direct = keywordMatched.filter((trip) => {
        const route = routeMap.get(trip.routeId);
        if (!route) return false;
        const oIdx = route.stops.findIndex((s) => s.villageName === origin);
        const dIdx = route.stops.findIndex((s) => s.villageName === destination);
        return oIdx !== -1 && dIdx !== -1 && oIdx < dIdx;
      });

      if (direct.length > 0) {
        return { filteredTrips: direct, matchType: 'direct' as const };
      }

      const returnCorridor = keywordMatched.filter((trip) => {
        const route = routeMap.get(trip.routeId);
        if (!route) return false;
        const oIdx = route.stops.findIndex((s) => s.villageName === origin);
        const dIdx = route.stops.findIndex((s) => s.villageName === destination);
        return oIdx !== -1 && dIdx !== -1;
      });

      if (returnCorridor.length > 0) {
        return { filteredTrips: returnCorridor, matchType: 'return' as const };
      }

      // Show connecting feeder buses serving the selected origin first, then destination
      const originFeeders = keywordMatched.filter((trip) => {
        const route = routeMap.get(trip.routeId);
        return route?.stops.some((s) => s.villageName === origin) ?? false;
      });
      const destFeeders = keywordMatched.filter((trip) => {
        const route = routeMap.get(trip.routeId);
        const hasDest = route?.stops.some((s) => s.villageName === destination) ?? false;
        const alreadyIncluded = originFeeders.some((o) => o.tripId === trip.tripId);
        return hasDest && !alreadyIncluded;
      });

      const connecting = [...originFeeders, ...destFeeders];
      if (connecting.length > 0) {
        return { filteredTrips: connecting, matchType: 'connecting' as const };
      }

      return { filteredTrips: [] as BusTrip[], matchType: 'direct' as const };
    }

    if (origin) {
      const byOrigin = keywordMatched.filter((trip) =>
        routeMap.get(trip.routeId)?.stops.some((s) => s.villageName === origin)
      );
      return { filteredTrips: byOrigin, matchType: 'direct' as const };
    }

    if (destination) {
      const byDest = keywordMatched.filter((trip) =>
        routeMap.get(trip.routeId)?.stops.some((s) => s.villageName === destination)
      );
      return { filteredTrips: byDest, matchType: 'direct' as const };
    }

    return { filteredTrips: keywordMatched, matchType: 'direct' as const };
  }, [trips, routeMap, origin, destination, keyword]);

  useEffect(() => {
    if (filteredTrips.length > 0) {
      const stillVisible = filteredTrips.some((t) => t.tripId === selectedTripId);
      if (!stillVisible) {
        setSelectedTripId(filteredTrips[0].tripId);
        setSelectedSeats([]);
      }
    }
  }, [filteredTrips, selectedTripId]);

  const activeTrip = useMemo(
    () =>
      filteredTrips.find((t) => t.tripId === selectedTripId) ??
      filteredTrips[0] ??
      null,
    [filteredTrips, selectedTripId]
  );

  const activeRoute = activeTrip ? routeMap.get(activeTrip.routeId) ?? null : null;

  // Deselect any seat that becomes occupied by a concurrent conductor/commuter update
  useEffect(() => {
    if (!activeTrip) return;
    const occupiedSet = new Set(
      activeTrip.seats.filter((s) => s.status === 'occupied').map((s) => s.seatNumber)
    );
    setSelectedSeats((prev) => prev.filter((s) => !occupiedSet.has(s)));
  }, [activeTrip]);

  const handleToggleSeat = (seatNumber: string) => {
    setSelectedSeats((prev) => {
      if (prev.includes(seatNumber)) {
        return prev.filter((s) => s !== seatNumber);
      }
      if (prev.length >= 6) return prev;
      return [...prev, seatNumber];
    });
  };

  const handleSpeak = (lang: AnnouncementLanguage, route: RuralRoute, trip: BusTrip) => {
    const result = speakBusAnnouncement(lang, route, trip);
    setAnnouncementTripId(trip.tripId);
    setAnnouncementText(
      result.supported
        ? result.spokenText
        : `${result.spokenText} (Audio playback unavailable in this browser)`
    );
  };

  const handleCrowdPing = async (trip: BusTrip, level: CrowdLevel) => {
    setPingLoadingId(trip.tripId);
    setPingFeedback(null);
    try {
      const res = await sendCrowdPing(token, trip.tripId, level, trip.currentStopName);
      onTripUpdated(res.trip);
      setPingFeedback(`Reported "${level}" for Route #${trip.routeNumber}.`);
    } catch (err) {
      setPingFeedback(
        err instanceof Error ? err.message : 'Could not submit crowd report while offline.'
      );
    } finally {
      setPingLoadingId(null);
    }
  };

  const renderSeatStatusBadge = (trip: BusTrip) => {
    if (trip.availableSeats > 0) {
      return (
        <span className="inline-flex items-center rounded border border-emerald-200 bg-emerald-50 px-2.5 py-1 font-mono text-xs font-bold text-emerald-800 tabular-nums">
          {trip.availableSeats} Seats Available
        </span>
      );
    }
    if (trip.status === 'Standing Only') {
      return (
        <span className="inline-flex items-center rounded border border-amber-200 bg-amber-50 px-2.5 py-1 font-mono text-xs font-bold text-amber-800">
          Standing Only · 0 Seats
        </span>
      );
    }
    return (
      <span className="inline-flex items-center rounded border border-red-200 bg-red-50 px-2.5 py-1 font-mono text-xs font-bold text-red-800">
        Full · 0 Seats
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Search & Filter Bar */}
      <section className="rounded-lg border border-slate-200 bg-white p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-slate-900">
              Rural Route &amp; Live Seat Finder
            </h1>
            <p className="text-xs text-slate-500">
              Search buses across 10 rural feeder routes and 25 village landmark boarding points
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                setOrigin('Narsapur');
                setDestination('Medak Town');
                setKeyword('');
              }}
              className="rounded-md border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-900 hover:bg-blue-100 whitespace-nowrap"
            >
              Preset: Narsapur → Medak Town
            </button>

            <span className="flex items-center gap-1.5 text-xs font-medium text-slate-600 whitespace-nowrap">
              {syncStatus === 'live' ? (
                <>
                  <Wifi className="h-3.5 w-3.5 text-emerald-700" aria-hidden="true" />
                  <span>Live Sync</span>
                </>
              ) : (
                <>
                  <WifiOff className="h-3.5 w-3.5 text-amber-700" aria-hidden="true" />
                  <span>{syncStatus === 'reconnecting' ? 'Connecting...' : 'Offline Cache'}</span>
                </>
              )}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-12">
          <div className="lg:col-span-3">
            <label htmlFor="filter-origin" className="mb-1 block text-xs font-semibold text-slate-700">
              Boarding Village
            </label>
            <select
              id="filter-origin"
              value={origin}
              onChange={(e) => setOrigin(e.target.value)}
              className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-700 focus:outline-none"
            >
              <option value="">All Origin Villages</option>
              {allVillages.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>
          </div>

          <div className="lg:col-span-3">
            <label htmlFor="filter-dest" className="mb-1 block text-xs font-semibold text-slate-700">
              Destination Town / Village
            </label>
            <select
              id="filter-dest"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-700 focus:outline-none"
            >
              <option value="">All Destinations</option>
              {allVillages.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>
          </div>

          <div className="lg:col-span-4">
            <label htmlFor="filter-kw" className="mb-1 block text-xs font-semibold text-slate-700">
              Route Number or Landmark Stop
            </label>
            <div className="relative">
              <Search
                className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400"
                aria-hidden="true"
              />
              <input
                id="filter-kw"
                type="text"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                placeholder="e.g., 312, Gram Panchayat Gate, Banyan Tree"
                className="w-full rounded-md border border-slate-300 bg-white py-2 pl-9 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-700 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-end lg:col-span-2">
            <button
              type="button"
              onClick={() => {
                setOrigin('');
                setDestination('');
                setKeyword('');
              }}
              className="min-h-[38px] w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
            >
              Reset Filters
            </button>
          </div>
        </div>
      </section>

      {error && (
        <div className="rounded-md border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
          {error}
        </div>
      )}

      {pingFeedback && (
        <div className="rounded-md border border-blue-200 bg-blue-50 px-4 py-2.5 text-xs font-medium text-blue-900">
          {pingFeedback}
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="lg:col-span-6 space-y-3">
            {[1, 2, 3].map((n) => (
              <div
                key={n}
                className="h-32 animate-pulse rounded-lg border border-slate-200 bg-white"
              />
            ))}
          </div>
          <div className="lg:col-span-6 h-96 animate-pulse rounded-lg border border-slate-200 bg-white" />
        </div>
      ) : filteredTrips.length === 0 ? (
        <div className="rounded-lg border border-slate-200 bg-white p-10 text-center space-y-3">
          <p className="text-base font-bold text-slate-900">
            No matching rural buses found
          </p>
          <p className="text-sm text-slate-600">
            Try clearing the origin/destination filter or search for another village landmark stop.
          </p>
          <button
            type="button"
            onClick={() => {
              setOrigin('');
              setDestination('');
              setKeyword('');
            }}
            className="inline-flex min-h-[40px] items-center rounded-md bg-blue-800 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-900"
          >
            Show All 10 Rural Routes
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 items-start">
          {/* Left Column: Departing Buses List */}
          <div className="lg:col-span-6 space-y-3">
            <div className="flex items-center justify-between px-1">
              <h2 className="text-sm font-bold text-slate-900">
                Departing Buses ({filteredTrips.length})
              </h2>
              <span className="text-xs text-slate-500">
                Select a bus to open 2×3 seats &amp; fare checkout
              </span>
            </div>

            {matchType === 'connecting' && origin && destination && (
              <div className="rounded-md border border-blue-200 bg-blue-50 px-3.5 py-2.5 text-xs text-blue-900">
                No direct single bus runs between <strong>{origin}</strong> and{' '}
                <strong>{destination}</strong>. Showing connecting rural feeder routes serving{' '}
                <strong>{origin}</strong> and <strong>{destination}</strong> via district hubs.
              </div>
            )}

            {matchType === 'return' && origin && destination && (
              <div className="rounded-md border border-blue-200 bg-blue-50 px-3.5 py-2.5 text-xs text-blue-900">
                Showing corridor route(s) connecting <strong>{origin}</strong> and{' '}
                <strong>{destination}</strong> (includes return direction on the same corridor).
              </div>
            )}

            {filteredTrips.map((trip) => {
              const route = routeMap.get(trip.routeId);
              if (!route) return null;
              const isSelected = activeTrip?.tripId === trip.tripId;
              const firstStop = route.stops[0];
              const lastStop = route.stops[route.stops.length - 1];
              const minFare = route.baseFare + route.stageRate;
              const maxFare =
                route.baseFare + (route.stops.length - 1) * route.stageRate;

              return (
                <article
                  key={trip.tripId}
                  className={`rounded-lg border bg-white p-4 transition-colors ${
                    isSelected
                      ? 'border-blue-800 ring-1 ring-blue-800'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedTripId(trip.tripId);
                        setSelectedSeats([]);
                      }}
                      className="text-left focus-visible:outline-2 focus-visible:outline-blue-700"
                    >
                      <p className="font-mono text-xs font-bold text-blue-800">
                        Route #{route.routeNumber} · {route.busType} · {trip.busRegistration}
                      </p>
                      <h3 className="mt-0.5 text-base font-bold text-slate-900">
                        {route.name}
                      </h3>
                    </button>

                    {renderSeatStatusBadge(trip)}
                  </div>

                  <div className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600">
                    <span className="font-mono font-semibold text-slate-900 tabular-nums">
                      Departs {trip.departureTime} (in {trip.departureInMins}m)
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="inline-flex items-center gap-1">
                      <MapPin className="h-3.5 w-3.5 text-slate-500" aria-hidden="true" />
                      <span>
                        {firstStop.villageName} ({firstStop.landmarkName}) → {lastStop.villageName}
                      </span>
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono font-medium text-slate-800 tabular-nums">
                      Fare ₹{minFare}–₹{maxFare}
                    </span>
                  </div>

                  {/* Crowd Ping Latest Info */}
                  {trip.crowdPing && (
                    <p className="mt-2 flex items-center gap-1.5 text-xs text-slate-600">
                      <Users className="h-3.5 w-3.5 text-slate-500 shrink-0" aria-hidden="true" />
                      <span>
                        Passenger ping: <strong className="text-slate-900">{trip.crowdPing.level}</strong>{' '}
                        at {trip.crowdPing.stopName}
                      </span>
                    </p>
                  )}

                  {/* Regional Voice Announcements + Crowd Ping + Select CTA */}
                  <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-3">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 mr-1">
                        <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                        Announce:
                      </span>
                      <button
                        type="button"
                        onClick={() => handleSpeak('en-IN', route, trip)}
                        className="rounded border border-slate-300 bg-white px-2 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-100"
                      >
                        EN
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSpeak('te-IN', route, trip)}
                        className="rounded border border-slate-300 bg-white px-2 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-100"
                      >
                        తెలుగు
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSpeak('hi-IN', route, trip)}
                        className="rounded border border-slate-300 bg-white px-2 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-100"
                      >
                        हिंदी
                      </button>
                      {announcementTripId === trip.tripId && announcementText && (
                        <button
                          type="button"
                          onClick={() => {
                            stopAnnouncement();
                            setAnnouncementText(null);
                            setAnnouncementTripId(null);
                          }}
                          className="inline-flex items-center gap-1 rounded border border-slate-300 bg-slate-100 px-2 py-1 text-[11px] font-medium text-slate-700"
                        >
                          <VolumeX className="h-3 w-3" aria-hidden="true" />
                          Stop
                        </button>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setSelectedTripId(trip.tripId);
                        setSelectedSeats([]);
                      }}
                      className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                        isSelected
                          ? 'bg-blue-800 text-white'
                          : 'border border-slate-300 bg-white text-slate-800 hover:bg-slate-100'
                      }`}
                    >
                      {isSelected ? 'Selected' : 'Select Seats & Pay'}
                    </button>
                  </div>

                  {announcementTripId === trip.tripId && announcementText && (
                    <p className="mt-2 rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-700">
                      {announcementText}
                    </p>
                  )}

                  {/* Quick 1-Tap Crowd-Sourced Occupancy Ping */}
                  <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] text-slate-500 mr-1">Crowd Ping:</span>
                    {CROWD_OPTIONS.map((lvl) => (
                      <button
                        key={lvl}
                        type="button"
                        disabled={pingLoadingId === trip.tripId}
                        onClick={() => void handleCrowdPing(trip, lvl)}
                        className="rounded border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-200 disabled:opacity-50"
                      >
                        {lvl}
                      </button>
                    ))}
                  </div>
                </article>
              );
            })}
          </div>

          {/* Right Column: Landmark Boarding Points + 2x3 Seat Map + UPI QR Checkout */}
          {activeTrip && activeRoute && (
            <div className="lg:col-span-6 space-y-5">
              {/* Landmark Boarding Stops */}
              <section className="rounded-lg border border-slate-200 bg-white p-5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-3">
                  <div>
                    <h2 className="text-base font-bold text-slate-900">
                      Route #{activeRoute.routeNumber} Landmark Boarding Points
                    </h2>
                    <p className="text-xs text-slate-500">
                      Informal community stops · Total distance{' '}
                      {activeRoute.stops[activeRoute.stops.length - 1].distanceKm} km
                    </p>
                  </div>
                  {renderSeatStatusBadge(activeTrip)}
                </div>

                <ol className="divide-y divide-slate-100">
                  {activeRoute.stops.map((stop) => (
                    <li
                      key={stop.stopId}
                      className="flex items-center justify-between gap-3 py-2.5 text-sm"
                    >
                      <div className="min-w-0">
                        <p className="font-semibold text-slate-900">
                          {stop.villageName}
                        </p>
                        <p className="text-xs text-slate-600">{stop.landmarkName}</p>
                      </div>
                      <div className="shrink-0 text-right font-mono text-xs text-slate-600 tabular-nums">
                        <p>Stage {stop.stageIndex}</p>
                        <p className="text-[11px] text-slate-500">
                          {stop.distanceKm} km · +{stop.etaOffsetMins}m
                        </p>
                      </div>
                    </li>
                  ))}
                </ol>
              </section>

              {/* 2x3 Bus Seat Layout */}
              <section className="rounded-lg border border-slate-200 bg-white p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-base font-bold text-slate-900">
                      Interactive 2×3 Bus Seat Map
                    </h2>
                    <p className="text-xs text-slate-500">
                      Tap up to 6 vacant seats to book your pass
                    </p>
                  </div>
                  <span className="font-mono text-xs font-semibold text-blue-900">
                    Selected: {selectedSeats.length > 0 ? selectedSeats.join(', ') : 'None'}
                  </span>
                </div>

                <BusSeatLayout
                  seats={activeTrip.seats}
                  selectedSeats={selectedSeats}
                  onToggleSeat={handleToggleSeat}
                />
              </section>

              {/* Stage Fare Calculator + Passenger Details + Scannable UPI QR */}
              <section className="rounded-lg border border-slate-200 bg-white p-5">
                <CheckoutPanel
                  route={activeRoute}
                  trip={activeTrip}
                  selectedSeats={selectedSeats}
                  user={user}
                  token={token}
                  preferredOrigin={origin}
                  preferredDestination={destination}
                  onTicketIssued={(updatedTrip, ticket) => {
                    onTripUpdated(updatedTrip);
                    setSelectedSeats([]);
                    onTicketIssued(updatedTrip, ticket);
                  }}
                />
              </section>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
