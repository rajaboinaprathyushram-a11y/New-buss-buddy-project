import { useMemo, useState } from 'react';
import { RefreshCw, ShieldAlert, ShieldCheck } from 'lucide-react';
import type { BusTrip, RuralRoute, UserProfile } from '../../shared/transit';
import { loginAccount, resetDemoTrips, updateConductorSeats } from '../services/api';

interface ConductorConsoleViewProps {
  routes: RuralRoute[];
  trips: BusTrip[];
  user: UserProfile;
  token: string;
  onTripUpdated: (trip: BusTrip) => void;
  onTripsSnapshot: (trips: BusTrip[]) => void;
  onRoleSwitchLogin: (token: string, user: UserProfile) => void;
}

export function ConductorConsoleView({
  routes,
  trips,
  user,
  token,
  onTripUpdated,
  onTripsSnapshot,
  onRoleSwitchLogin,
}: ConductorConsoleViewProps) {
  const [selectedTripId, setSelectedTripId] = useState<string>('TRIP-312-A');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const routeMap = useMemo(() => {
    const map = new Map<string, RuralRoute>();
    for (const r of routes) map.set(r.id, r);
    return map;
  }, [routes]);

  const activeTrip = useMemo(
    () => trips.find((t) => t.tripId === selectedTripId) ?? trips[0] ?? null,
    [trips, selectedTripId]
  );
  const activeRoute = activeTrip ? routeMap.get(activeTrip.routeId) ?? null : null;

  const handleSeatUpdate = async (payload: { delta?: number; mode?: 'standing' | 'full' }) => {
    if (!activeTrip) return;
    setBusy(true);
    setError(null);
    setStatusMessage(null);
    try {
      const res = await updateConductorSeats(token, activeTrip.tripId, payload);
      onTripUpdated(res.trip);
      setStatusMessage(
        `Updated Route #${res.trip.routeNumber} → ${res.trip.availableSeats} Seats (${res.trip.status})`
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update seat count.');
    } finally {
      setBusy(false);
    }
  };

  const handleResetDemo = async () => {
    setBusy(true);
    setError(null);
    setStatusMessage(null);
    try {
      const res = await resetDemoTrips(token);
      onTripsSnapshot(res.trips);
      setStatusMessage('Demo trip seat counts reset (Route #312 restored to 14 Seats Available).');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reset demo trips.');
    } finally {
      setBusy(false);
    }
  };

  const handleSwitchToConductorDemo = async () => {
    setBusy(true);
    setError(null);
    try {
      const res = await loginAccount('venkat.312@rtc-demo.in', 'conductor123');
      onRoleSwitchLogin(res.token, res.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to switch to Conductor account.');
    } finally {
      setBusy(false);
    }
  };

  if (user.role !== 'conductor') {
    return (
      <div className="mx-auto max-w-2xl rounded-lg border border-slate-200 bg-white p-8 space-y-5">
        <div className="flex items-start gap-3">
          <ShieldAlert className="h-6 w-6 shrink-0 text-amber-700" aria-hidden="true" />
          <div className="space-y-1">
            <h1 className="text-lg font-bold text-slate-900">
              Conductor Authorization Required
            </h1>
            <p className="text-sm text-slate-600">
              You are currently signed in as a Commuter (<strong>{user.name}</strong>). Official
              bus seat count adjustments are restricted to verified RTC conductors.
            </p>
          </div>
        </div>

        {error && (
          <div className="rounded-md border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-800">
            {error}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3 pt-1">
          <button
            type="button"
            disabled={busy}
            onClick={() => void handleSwitchToConductorDemo()}
            className="inline-flex min-h-[48px] items-center gap-2 rounded-md bg-blue-800 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-900 disabled:opacity-60"
          >
            <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            <span>
              {busy ? 'Switching Session...' : 'Sign In as Demo Conductor (Route #312)'}
            </span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <section className="rounded-lg border border-slate-200 bg-white p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-slate-900">
              Conductor Quick-Update Console
            </h1>
            <p className="text-xs text-slate-500">
              Large 64px+ blind-tap buttons for updating live vacant seats while issuing tickets
              on a moving bus
            </p>
          </div>

          <button
            type="button"
            disabled={busy}
            onClick={() => void handleResetDemo()}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-100 disabled:opacity-50"
          >
            <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Reset Demo Trips (#312 → 14 Seats)</span>
          </button>
        </div>

        <div>
          <label htmlFor="conductor-trip-select" className="mb-1.5 block text-xs font-semibold text-slate-700">
            Active Bus Trip
          </label>
          <select
            id="conductor-trip-select"
            value={activeTrip?.tripId ?? ''}
            onChange={(e) => setSelectedTripId(e.target.value)}
            className="w-full max-w-xl rounded-md border border-slate-300 bg-white px-3 py-2.5 text-sm font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
          >
            {trips.map((trip) => {
              const r = routeMap.get(trip.routeId);
              return (
                <option key={trip.tripId} value={trip.tripId}>
                  Route #{trip.routeNumber} — {r?.name ?? ''} ({trip.busRegistration} ·{' '}
                  {trip.availableSeats} Seats)
                </option>
              );
            })}
          </select>
        </div>
      </section>

      {error && (
        <div role="alert" className="rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
          {error}
        </div>
      )}

      {statusMessage && (
        <div className="rounded-md border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-900">
          {statusMessage}
        </div>
      )}

      {activeTrip && activeRoute && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 items-start">
          {/* Touch-First 64px+ Update Panel */}
          <section className="lg:col-span-7 rounded-lg border border-slate-200 bg-white p-6 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
              <div>
                <p className="font-mono text-xs font-bold text-blue-800">
                  Route #{activeRoute.routeNumber} · {activeTrip.busRegistration}
                </p>
                <h2 className="mt-0.5 text-lg font-bold text-slate-900">
                  {activeRoute.name}
                </h2>
                <p className="text-xs text-slate-500">
                  Current Stop: {activeTrip.currentStopName}
                </p>
              </div>

              <div className="rounded-lg border border-slate-200 bg-slate-50 px-5 py-3 text-center">
                <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                  Vacant Seats
                </p>
                <p className="font-mono text-4xl font-bold text-slate-900 tabular-nums">
                  {activeTrip.availableSeats}
                </p>
                <p
                  className={`mt-0.5 text-xs font-bold ${
                    activeTrip.availableSeats > 0
                      ? 'text-emerald-700'
                      : activeTrip.status === 'Standing Only'
                      ? 'text-amber-700'
                      : 'text-red-700'
                  }`}
                >
                  {activeTrip.availableSeats > 0
                    ? `${activeTrip.availableSeats} Seats Available`
                    : activeTrip.status}
                </p>
              </div>
            </div>

            {/* Giant >= 64px Boarding Buttons (Passengers Boarding = Decrement) */}
            <div className="space-y-2.5">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-600">
                Passengers Boarding (Decrement Vacant Seats)
              </p>
              <div className="grid grid-cols-3 gap-3">
                {[-1, -2, -3].map((delta) => (
                  <button
                    key={delta}
                    type="button"
                    disabled={busy || activeTrip.availableSeats === 0}
                    onClick={() => void handleSeatUpdate({ delta })}
                    className="flex min-h-[72px] flex-col items-center justify-center rounded-lg border-2 border-slate-900 bg-slate-900 px-4 py-3 text-white transition-transform active:scale-[0.98] hover:bg-slate-800 disabled:cursor-not-allowed disabled:border-slate-300 disabled:bg-slate-200 disabled:text-slate-500"
                  >
                    <span className="font-mono text-2xl font-bold tabular-nums">{delta}</span>
                    <span className="text-xs font-medium">
                      {Math.abs(delta) === 1 ? '1 Passenger' : `${Math.abs(delta)} Passengers`}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Giant >= 64px Alighting Buttons (Seats Freed = Increment) */}
            <div className="space-y-2.5">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-600">
                Passengers Alighting (Add Vacant Seats)
              </p>
              <div className="grid grid-cols-2 gap-3">
                {[1, 2].map((delta) => (
                  <button
                    key={delta}
                    type="button"
                    disabled={busy || activeTrip.availableSeats >= activeTrip.totalSeats}
                    onClick={() => void handleSeatUpdate({ delta })}
                    className="flex min-h-[68px] flex-col items-center justify-center rounded-lg border-2 border-emerald-700 bg-emerald-50 px-4 py-3 text-emerald-950 transition-transform active:scale-[0.98] hover:bg-emerald-100 disabled:cursor-not-allowed disabled:border-slate-200 disabled:bg-slate-100 disabled:text-slate-400"
                  >
                    <span className="font-mono text-2xl font-bold tabular-nums">+{delta}</span>
                    <span className="text-xs font-semibold">
                      {delta === 1 ? '1 Seat Freed' : '2 Seats Freed'}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Status Overrides */}
            <div className="grid grid-cols-1 gap-3 border-t border-slate-200 pt-4 sm:grid-cols-2">
              <button
                type="button"
                disabled={busy}
                onClick={() => void handleSeatUpdate({ mode: 'standing' })}
                className="min-h-[64px] rounded-lg border-2 border-amber-700 bg-amber-50 px-4 py-3 text-sm font-bold text-amber-950 hover:bg-amber-100 active:scale-[0.98] disabled:opacity-50"
              >
                Mark Standing Only (0 Seats)
              </button>
              <button
                type="button"
                disabled={busy}
                onClick={() => void handleSeatUpdate({ mode: 'full' })}
                className="min-h-[64px] rounded-lg border-2 border-red-700 bg-red-50 px-4 py-3 text-sm font-bold text-red-950 hover:bg-red-100 active:scale-[0.98] disabled:opacity-50"
              >
                Mark Bus Full (No Boarding)
              </button>
            </div>
          </section>

          {/* Right Column: Live Audit Log */}
          <aside className="lg:col-span-5 rounded-lg border border-slate-200 bg-white p-5 space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-slate-900">
                Recent Seat Sync Log
              </h2>
              <p className="text-xs text-slate-500">
                Every tap broadcasts immediately to waiting village commuters
              </p>
            </div>

            {activeTrip.recentLogs.length === 0 ? (
              <p className="py-6 text-center text-xs text-slate-500">
                No seat adjustments logged yet for this trip. Tap a button on the left to test
                instant sync.
              </p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {activeTrip.recentLogs.map((log) => (
                  <li key={log.id} className="py-2.5 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-semibold text-slate-900">{log.actionLabel}</span>
                      <span className="font-mono font-bold text-blue-900 tabular-nums">
                        {log.previousSeats} → {log.newSeats} seats
                      </span>
                    </div>
                    <p className="mt-0.5 text-[11px] text-slate-500">
                      {log.conductorName} · {new Date(log.timestamp).toLocaleTimeString()}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}
