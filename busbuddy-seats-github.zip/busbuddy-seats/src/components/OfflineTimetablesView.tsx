import { useMemo, useState } from 'react';
import { HardDrive, Search } from 'lucide-react';
import type { BusTrip, RuralRoute } from '../../shared/transit';

interface OfflineTimetablesViewProps {
  routes: RuralRoute[];
  trips: BusTrip[];
  cachedAt: string | null;
}

export function OfflineTimetablesView({
  routes,
  trips,
  cachedAt,
}: OfflineTimetablesViewProps) {
  const [filter, setFilter] = useState('');

  const tripByRoute = useMemo(() => {
    const map = new Map<string, BusTrip>();
    for (const t of trips) map.set(t.routeId, t);
    return map;
  }, [trips]);

  const filteredRoutes = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return routes;
    return routes.filter(
      (r) =>
        r.routeNumber.toLowerCase().includes(q) ||
        r.name.toLowerCase().includes(q) ||
        r.stops.some(
          (s) =>
            s.villageName.toLowerCase().includes(q) ||
            s.landmarkName.toLowerCase().includes(q)
        )
    );
  }, [routes, filter]);

  return (
    <div className="space-y-5">
      <section className="rounded-lg border border-slate-200 bg-white p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-slate-900">
              Offline Cached District Timetables
            </h1>
            <p className="text-xs text-slate-500">
              All 10 rural feeder routes and 25 landmark stops are stored in browser localStorage for
              2G signal dropouts
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <HardDrive className="h-4 w-4 text-emerald-700" aria-hidden="true" />
            <span>
              {cachedAt
                ? `Cached locally at ${new Date(cachedAt).toLocaleTimeString()}`
                : 'Cached locally'}
            </span>
          </div>
        </div>

        <div className="relative max-w-md">
          <Search
            className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400"
            aria-hidden="true"
          />
          <input
            type="text"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Filter by route #, village, or landmark..."
            className="w-full rounded-md border border-slate-300 bg-white py-2 pl-9 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-700 focus:outline-none"
          />
        </div>
      </section>

      <section className="overflow-hidden rounded-lg border border-slate-200 bg-white">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700">
                <th className="px-4 py-3">Route</th>
                <th className="px-4 py-3">Corridor &amp; Coach</th>
                <th className="px-4 py-3">Landmark Boarding Stops</th>
                <th className="px-4 py-3 text-right">Departure</th>
                <th className="px-4 py-3 text-right">Stage Fares</th>
                <th className="px-4 py-3 text-right">Last Known Seats</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredRoutes.map((route) => {
                const trip = tripByRoute.get(route.id);
                const minFare = route.baseFare + route.stageRate;
                const maxFare =
                  route.baseFare + (route.stops.length - 1) * route.stageRate;

                return (
                  <tr key={route.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 align-top font-mono font-bold text-blue-900">
                      #{route.routeNumber}
                    </td>
                    <td className="px-4 py-3 align-top">
                      <p className="font-semibold text-slate-900">{route.name}</p>
                      <p className="text-xs text-slate-500">
                        {route.busType} · {trip?.busRegistration ?? 'RTC Coach'}
                      </p>
                    </td>
                    <td className="px-4 py-3 align-top text-xs text-slate-700">
                      {route.stops.map((s, idx) => (
                        <span key={s.stopId}>
                          <strong className="text-slate-900">{s.villageName}</strong> (
                          {s.landmarkName})
                          {idx < route.stops.length - 1 ? ' → ' : ''}
                        </span>
                      ))}
                    </td>
                    <td className="px-4 py-3 align-top text-right font-mono text-xs text-slate-800 tabular-nums whitespace-nowrap">
                      {trip ? trip.departureTime : 'Scheduled'}
                    </td>
                    <td className="px-4 py-3 align-top text-right font-mono text-xs font-semibold text-slate-900 tabular-nums whitespace-nowrap">
                      ₹{minFare} – ₹{maxFare}
                    </td>
                    <td className="px-4 py-3 align-top text-right font-mono text-xs font-bold tabular-nums whitespace-nowrap">
                      {trip ? (
                        trip.availableSeats > 0 ? (
                          <span className="text-emerald-700">
                            {trip.availableSeats} Seats
                          </span>
                        ) : (
                          <span className="text-amber-700">{trip.status}</span>
                        )
                      ) : (
                        '—'
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
