import { Armchair } from 'lucide-react';
import type { BusSeat } from '../../shared/transit';

interface BusSeatLayoutProps {
  seats: BusSeat[];
  selectedSeats: string[];
  onToggleSeat: (seatNumber: string) => void;
  disabled?: boolean;
}

export function BusSeatLayout({
  seats,
  selectedSeats,
  onToggleSeat,
  disabled = false,
}: BusSeatLayoutProps) {
  const rows: Record<number, BusSeat[]> = {};
  for (const seat of seats) {
    if (!rows[seat.row]) rows[seat.row] = [];
    rows[seat.row].push(seat);
  }
  const rowNumbers = Object.keys(rows)
    .map(Number)
    .sort((a, b) => a - b);

  const selectedSet = new Set(selectedSeats);

  const renderSeatButton = (seat: BusSeat) => {
    const isSelected = selectedSet.has(seat.seatNumber);
    const isOccupied = seat.status === 'occupied';
    const isFemale = seat.status === 'female';

    let styleClass =
      'border-emerald-600 bg-emerald-50 text-emerald-950 hover:bg-emerald-100';
    if (isSelected) {
      styleClass = 'border-blue-900 bg-blue-800 text-white';
    } else if (isOccupied) {
      styleClass =
        'border-slate-300 bg-slate-200 text-slate-400 cursor-not-allowed';
    } else if (isFemale) {
      styleClass =
        'border-rose-600 bg-rose-50 text-rose-950 hover:bg-rose-100';
    }

    const statusDescription = isSelected
      ? 'Selected'
      : isOccupied
      ? 'Reserved / Occupied'
      : isFemale
      ? 'Female-Reserved Available'
      : 'Available';

    return (
      <button
        key={seat.seatNumber}
        type="button"
        disabled={disabled || isOccupied}
        onClick={() => onToggleSeat(seat.seatNumber)}
        aria-label={`Seat ${seat.seatNumber}, ${statusDescription}`}
        aria-pressed={isSelected}
        title={`Seat ${seat.seatNumber} (${statusDescription})`}
        className={`flex h-11 w-11 flex-col items-center justify-center rounded border text-[11px] font-mono font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700 ${styleClass}`}
      >
        <span>{seat.seatNumber}</span>
        {isFemale && !isSelected && (
          <span className="text-[9px] font-bold leading-none text-rose-700">F</span>
        )}
        {isOccupied && (
          <span className="text-[9px] leading-none text-slate-400">X</span>
        )}
      </button>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-4 text-xs text-slate-700">
        <div className="flex items-center gap-1.5">
          <span className="inline-block h-4 w-4 rounded border border-emerald-600 bg-emerald-50" />
          <span>Available</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="inline-flex h-4 w-4 items-center justify-center rounded border border-rose-600 bg-rose-50 text-[9px] font-bold text-rose-700">
            F
          </span>
          <span>Female Reserved</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="inline-flex h-4 w-4 items-center justify-center rounded border border-slate-300 bg-slate-200 text-[9px] text-slate-500">
            X
          </span>
          <span>Occupied</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="inline-block h-4 w-4 rounded border border-blue-900 bg-blue-800" />
          <span>Selected</span>
        </div>
      </div>

      <div className="mx-auto max-w-sm rounded-lg border border-slate-300 bg-slate-50 p-4">
        {/* Bus Front Cabin */}
        <div className="mb-3 flex items-center justify-between border-b border-slate-300 pb-2.5 text-xs font-semibold text-slate-600">
          <span className="rounded border border-slate-300 bg-white px-2 py-1">
            Front Door
          </span>
          <span className="flex items-center gap-1.5 text-slate-800">
            <Armchair className="h-4 w-4" aria-hidden="true" />
            Driver Cabin
          </span>
        </div>

        {/* 2x3 Seating Rows */}
        <div className="space-y-2">
          {rowNumbers.map((rowNum) => {
            const rowSeats = rows[rowNum].sort((a, b) => a.column - b.column);
            const leftBench = rowSeats.filter((s) => s.side === 'left');
            const rightBench = rowSeats.filter((s) => s.side === 'right');

            return (
              <div
                key={rowNum}
                className="flex items-center justify-between gap-2"
              >
                <div className="flex items-center gap-1.5">
                  {leftBench.map(renderSeatButton)}
                </div>

                <div
                  className="flex h-11 w-6 items-center justify-center text-[10px] font-mono text-slate-400"
                  aria-hidden="true"
                >
                  {rowNum}
                </div>

                <div className="flex items-center gap-1.5">
                  {rightBench.map(renderSeatButton)}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-3 border-t border-slate-300 pt-2 text-center text-[11px] font-medium text-slate-500">
          Standard 2×3 RTC Coach Layout · 45 Total Seats
        </div>
      </div>
    </div>
  );
}
