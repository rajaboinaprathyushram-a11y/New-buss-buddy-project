import QRCode from 'qrcode';
import { useEffect, useState } from 'react';
import { Download, FileText, Printer, Ticket } from 'lucide-react';
import type { TicketPass } from '../../shared/transit';
import { downloadBoardingPassHtml, downloadBoardingPassText } from '../utils/ticketExport';

interface TicketPassViewProps {
  passes: TicketPass[];
  activePassId: string | null;
  onSelectPass: (ticketId: string) => void;
  onBackToFinder: () => void;
}

export function TicketPassView({
  passes,
  activePassId,
  onSelectPass,
  onBackToFinder,
}: TicketPassViewProps) {
  const activePass =
    passes.find((p) => p.ticketId === activePassId) ?? passes[0] ?? null;
  const [qrUrl, setQrUrl] = useState('');

  useEffect(() => {
    if (!activePass) {
      setQrUrl('');
      return;
    }
    const verifyPayload = JSON.stringify({
      ticketId: activePass.ticketId,
      route: activePass.routeNumber,
      seats: activePass.seatNumbers,
      fare: activePass.farePaid,
      upiRef: activePass.upiRef,
    });
    let cancelled = false;
    QRCode.toDataURL(verifyPayload, {
      width: 180,
      margin: 1,
      color: { dark: '#0f172a', light: '#ffffff' },
    })
      .then((url) => {
        if (!cancelled) setQrUrl(url);
      })
      .catch(() => {
        if (!cancelled) setQrUrl('');
      });

    return () => {
      cancelled = true;
    };
  }, [activePass]);

  if (passes.length === 0) {
    return (
      <div className="rounded-lg border border-slate-200 bg-white p-10 text-center space-y-4">
        <Ticket className="mx-auto h-10 w-10 text-slate-400" aria-hidden="true" />
        <div className="space-y-1">
          <h2 className="text-lg font-bold text-slate-900">No Digital Boarding Passes Yet</h2>
          <p className="mx-auto max-w-md text-sm text-slate-600">
            Select a bus in Route Finder, pick available seats on the 2×3 layout, and complete the
            UPI QR checkout to generate an offline printable boarding pass.
          </p>
        </div>
        <button
          type="button"
          onClick={onBackToFinder}
          className="inline-flex min-h-[44px] items-center justify-center rounded-md bg-blue-800 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-900"
        >
          Find Rural Bus Routes
        </button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Left: Saved Passes List */}
      <aside className="no-print lg:col-span-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900">
            Saved Offline Passes ({passes.length})
          </h2>
        </div>
        <div className="divide-y divide-slate-200 rounded-lg border border-slate-200 bg-white">
          {passes.map((pass) => {
            const isSelected = activePass?.ticketId === pass.ticketId;
            return (
              <button
                key={pass.ticketId}
                type="button"
                onClick={() => onSelectPass(pass.ticketId)}
                className={`flex w-full items-start justify-between gap-3 p-4 text-left transition-colors ${
                  isSelected ? 'bg-blue-50' : 'hover:bg-slate-50'
                }`}
              >
                <div className="min-w-0 space-y-1">
                  <p className="font-mono text-xs font-bold text-blue-900">
                    {pass.ticketId} · Route #{pass.routeNumber}
                  </p>
                  <p className="truncate text-sm font-semibold text-slate-900">
                    {pass.boardingVillage} → {pass.dropVillage}
                  </p>
                  <p className="text-xs text-slate-500">
                    Seats {pass.seatNumbers.join(', ')} · {pass.departureTime}
                  </p>
                </div>
                <span className="shrink-0 font-mono text-sm font-bold text-slate-900 tabular-nums">
                  ₹{pass.farePaid}
                </span>
              </button>
            );
          })}
        </div>
      </aside>

      {/* Right: Printable Offline Boarding Pass */}
      {activePass && (
        <section className="lg:col-span-8 space-y-4">
          <div className="no-print flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                Offline Digital Boarding Pass
              </h2>
              <p className="text-xs text-slate-500">
                Cached locally for conductor inspection even with zero mobile signal
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-md bg-blue-800 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-900"
              >
                <Printer className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Print / Save PDF</span>
              </button>
              <button
                type="button"
                onClick={() => downloadBoardingPassHtml(activePass, qrUrl)}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-100"
              >
                <Download className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Download Pass (.html)</span>
              </button>
              <button
                type="button"
                onClick={() => downloadBoardingPassText(activePass)}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-100"
              >
                <FileText className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Download Voucher (.txt)</span>
              </button>
            </div>
          </div>

          <article className="print-pass rounded-lg border-2 border-slate-900 bg-white p-6">
            <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-blue-800">
                  State Rural Transport · Valid Boarding Pass
                </p>
                <h3 className="mt-1 text-xl font-bold text-slate-900">
                  Route #{activePass.routeNumber} — {activePass.routeName}
                </h3>
                <p className="mt-0.5 text-xs text-slate-600">
                  Coach {activePass.busRegistration} · Scheduled Departure{' '}
                  <span className="font-mono font-semibold text-slate-900">
                    {activePass.departureTime}
                  </span>
                </p>
              </div>
              <div className="text-left sm:text-right">
                <p className="text-[11px] font-medium uppercase text-slate-500">Pass ID</p>
                <p className="font-mono text-base font-bold text-slate-900">
                  {activePass.ticketId}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 py-5 sm:grid-cols-2 lg:grid-cols-3">
              <div>
                <p className="text-[11px] font-medium uppercase text-slate-500">Passenger</p>
                <p className="mt-0.5 text-sm font-semibold text-slate-900">
                  {activePass.passengerName}
                </p>
                <p className="font-mono text-xs text-slate-600">{activePass.passengerPhone}</p>
              </div>

              <div>
                <p className="text-[11px] font-medium uppercase text-slate-500">
                  Boarding Landmark
                </p>
                <p className="mt-0.5 text-sm font-semibold text-slate-900">
                  {activePass.boardingVillage}
                </p>
                <p className="text-xs text-slate-600">{activePass.boardingLandmark}</p>
              </div>

              <div>
                <p className="text-[11px] font-medium uppercase text-slate-500">Drop Destination</p>
                <p className="mt-0.5 text-sm font-semibold text-slate-900">
                  {activePass.dropVillage}
                </p>
                <p className="text-xs text-slate-600">{activePass.dropLandmark}</p>
              </div>

              <div>
                <p className="text-[11px] font-medium uppercase text-slate-500">
                  Reserved Seats
                </p>
                <p className="mt-0.5 font-mono text-base font-bold text-blue-900">
                  {activePass.seatNumbers.join(', ')}
                </p>
              </div>

              <div>
                <p className="text-[11px] font-medium uppercase text-slate-500">
                  Fare &amp; Concession
                </p>
                <p className="mt-0.5 font-mono text-base font-bold text-emerald-800 tabular-nums">
                  ₹{activePass.farePaid} Paid
                </p>
                <p className="text-xs text-slate-600">
                  {activePass.studentConcession
                    ? `Student Pass (${activePass.studentPassId})`
                    : `${activePass.stages} Stage(s) · Adult Fare`}
                </p>
              </div>

              <div>
                <p className="text-[11px] font-medium uppercase text-slate-500">
                  UPI Verification Ref
                </p>
                <p className="mt-0.5 font-mono text-xs font-semibold text-slate-900">
                  {activePass.upiRef}
                </p>
                <p className="text-xs text-slate-500">
                  {new Date(activePass.issuedAt).toLocaleString()}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-4 border-t border-dashed border-slate-300 pt-4">
              <div className="space-y-1 text-xs text-slate-600">
                <p className="font-semibold text-slate-900">
                  Show this offline pass to the bus conductor upon boarding.
                </p>
                <p>
                  Payee: {activePass.upiId} · Verified Offline Digital Boarding Pass
                </p>
              </div>
              {qrUrl && (
                <img
                  src={qrUrl}
                  alt={`Boarding verification QR for ${activePass.ticketId}`}
                  className="h-24 w-24 rounded border border-slate-200 p-1"
                />
              )}
            </div>
          </article>
        </section>
      )}
    </div>
  );
}
