import { Bus, ClipboardCheck, Clock, Search, Ticket } from 'lucide-react';
import type { UserProfile } from '../../shared/transit';

export type AppView = 'finder' | 'conductor' | 'passes' | 'timetables';

interface TopNavbarProps {
  activeView: AppView;
  onNavigate: (view: AppView) => void;
  user: UserProfile;
  onLogout: () => void;
}

const NAV_ITEMS: Array<{ id: AppView; label: string; mobileLabel: string }> = [
  { id: 'finder', label: 'Route Finder', mobileLabel: 'Finder' },
  { id: 'conductor', label: 'Conductor Console', mobileLabel: 'Conductor' },
  { id: 'passes', label: 'My Passes', mobileLabel: 'Passes' },
  { id: 'timetables', label: 'Offline Timetables', mobileLabel: 'Timetables' },
];

export function TopNavbar({ activeView, onNavigate, user, onLogout }: TopNavbarProps) {
  return (
    <>
      <header className="no-print sticky top-0 z-30 border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-4 py-3 sm:px-6">
          {/* Zone 1: Brand Wordmark */}
          <button
            type="button"
            onClick={() => onNavigate('finder')}
            className="flex shrink-0 items-center gap-2.5 text-left text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700"
          >
            <Bus className="h-5 w-5 text-blue-800" aria-hidden="true" />
            <span>BusBuddy Seats</span>
          </button>

          {/* Zone 2: 4 Single-Line Nav Links */}
          <nav className="hidden md:flex items-center gap-7" aria-label="Primary navigation">
            {NAV_ITEMS.map((item) => {
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onNavigate(item.id)}
                  className={`whitespace-nowrap shrink-0 border-b-2 py-1 text-sm font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-700 ${
                    isActive
                      ? 'border-blue-800 text-slate-900'
                      : 'border-transparent text-slate-600 hover:border-slate-300 hover:text-slate-900'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex shrink-0 items-center gap-4">
            <span className="hidden lg:inline text-xs text-slate-500 whitespace-nowrap">
              {user.name}
            </span>
            <button
              type="button"
              onClick={onLogout}
              className="whitespace-nowrap shrink-0 rounded-md border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-800 transition-colors hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700"
            >
              Sign Out
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Bottom Tab Bar (under 15% mobile height) */}
      <nav
        className="no-print fixed bottom-0 left-0 right-0 z-30 grid grid-cols-4 border-t border-slate-200 bg-white md:hidden"
        aria-label="Mobile navigation"
      >
        {NAV_ITEMS.map((item) => {
          const isActive = activeView === item.id;
          const Icon =
            item.id === 'finder'
              ? Search
              : item.id === 'conductor'
              ? ClipboardCheck
              : item.id === 'passes'
              ? Ticket
              : Clock;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={`flex min-h-[52px] flex-col items-center justify-center gap-1 px-1 py-1.5 text-[11px] font-medium whitespace-nowrap ${
                isActive ? 'text-blue-800' : 'text-slate-600'
              }`}
            >
              <Icon className="h-4 w-4" aria-hidden="true" />
              <span>{item.mobileLabel}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
}
