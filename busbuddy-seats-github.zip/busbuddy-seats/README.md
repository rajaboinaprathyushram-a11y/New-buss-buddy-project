# BusBuddy Seats: VillageRoute Rush

A rural state transport (RTC) route finder, live seat availability tracker, 2×3 coach seat mapper, stage-based fare calculator with scannable UPI QR payment, and conductor quick-update console.

## Features Implemented

- **Authentication & Role Portal**: Sign-in and Commuter registration page backed by salted `scrypt` password verification and HMAC-SHA256 Bearer session tokens.
- **Rural Route & Landmark Finder**: Search 10 rural feeder routes across 25 village landmark stops (e.g., *Narsapur · Gram Panchayat Gate* to *Medak Town*).
- **Live Conductor Seat Sync (WebSockets)**: Real-time seat count updates over `/ws` so conductor adjustments update waiting commuters immediately.
- **Interactive 2×3 Bus Seat Layout**: 45-seat coach diagram displaying Available, Female-Reserved (`F`), Occupied (`X`), and Selected seats.
- **Stage Fare Calculator & UPI QR Checkout**: Computes `Fare = BaseFare + (Stages × StageRate)` with a 40% Student Bus Pass concession, collects validated passenger details, generates a scannable `upi://pay` QR code, and issues a printable/downloadable offline boarding pass (`.html` / `.txt`).
- **Conductor Quick-Update Console**: High-contrast `64px+` thumb-tap buttons (`-1`, `-2`, `-3`, `+1`, `+2`, `Standing Only`, `Bus Full`).
- **Regional Voice Announcements & Crowd Pings**: Spoken departure alerts in English, Telugu (`te-IN`), and Hindi (`hi-IN`) via the Web Speech API, plus 1-tap passenger crowd reports.
- **Offline Timetable Caching**: Persists daily schedules and issued boarding passes in `localStorage` for low-signal rural dropouts.

## Running in VS Code (Step-by-Step)

### Prerequisites
- Install **Node.js (v20 LTS or newer)** from [nodejs.org](https://nodejs.org) (this includes `npm`).
- Install **Visual Studio Code** from [code.visualstudio.com](https://code.visualstudio.com).

### Steps
1. **Save the project folder**: Download the project files from the Code tab into a normal folder (for example, `busbuddy-seats`) on your computer.
2. **Open in VS Code**: Open VS Code → click **File → Open Folder...** → select your `busbuddy-seats` folder.
3. **Open the Integrated Terminal**: Press ``Ctrl + ` `` (or go to **Terminal → New Terminal** in the top menu).
4. **Install dependencies** (first time only):
   ```bash
   npm install
   ```
5. **Start the application** (runs Express API + WebSocket server + React frontend together on port 3000):
   ```bash
   npm run dev
   ```
6. **Open in browser**: Hold `Ctrl` (or `Cmd` on Mac) and click `http://localhost:3000` in the terminal, or open `http://localhost:3000` in Chrome/Edge.

### Useful Commands
- `npm run dev` — Start development server (Express + WebSocket + Vite) on port `3000`.
- `npm run lint` — Run TypeScript type check (`tsc --noEmit`).
- `npm run build` — Build production client bundle into `dist/`.
- `npm start` — Run the production server after `npm run build`.

## Demo Credentials (Pre-Seeded)

- **Student / Commuter**: `ravi.narsapur@rtc-demo.in` / `commuter123`
- **RTC Conductor (Route #312)**: `venkat.312@rtc-demo.in` / `conductor123`

## Presentation Demo Walkthrough

1. Sign in as **Demo Student** (or open a second browser tab) and click **Preset: Narsapur → Medak Town**. Route `#312` displays `14 Seats Available` at `Gram Panchayat Gate`.
2. Open **Conductor Console** in a second tab as **Demo Conductor** and tap **`-3`**.
3. The Commuter tab updates instantaneously to **`11 Seats Available`**.
4. Select seat(s) on the 2×3 map, fill passenger details, scan/confirm the generated UPI QR code, and print or download the offline digital boarding pass.

## Documented Assumptions

- **UPI Payment Verification**: Generates a genuine scannable `upi://pay` QR code with RTC depot details and uses an interactive UTR reference confirmation step suitable for a live academic demo without requiring live bank webhooks.
- **Data Storage**: Uses a local JSON file store (`server/data/store.json`) on the Express server so the project runs cleanly out of the box with zero external database setup.
- **Student Pass Concession**: Applies a 40% subsidy to the first passenger seat when a valid Student Bus Pass ID is provided (minimum ₹10 fare).
