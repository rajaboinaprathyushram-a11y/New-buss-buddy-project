import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import type {
  BusTrip,
  CrowdPing,
  RuralRoute,
  TicketPass,
  TripAvailabilityStatus,
} from '../shared/transit';
import { createSeedUsers, type StoredUser } from './auth';
import {
  buildSeatLayout,
  createInitialTrips,
  deriveAvailabilityStatus,
  RURAL_ROUTES,
} from './seedData';

interface PersistedStore {
  routes: RuralRoute[];
  trips: BusTrip[];
  users: StoredUser[];
  tickets: TicketPass[];
}

const DATA_DIR = path.resolve(process.cwd(), 'server', 'data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

function ensureStoreLoaded(): PersistedStore {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  if (fs.existsSync(STORE_PATH)) {
    try {
      const raw = fs.readFileSync(STORE_PATH, 'utf8');
      const parsed = JSON.parse(raw) as PersistedStore;
      if (
        Array.isArray(parsed.routes) &&
        Array.isArray(parsed.trips) &&
        Array.isArray(parsed.users) &&
        Array.isArray(parsed.tickets)
      ) {
        return parsed;
      }
    } catch {
      // Fall back to fresh seed store if JSON file is corrupted
    }
  }

  const initial: PersistedStore = {
    routes: RURAL_ROUTES,
    trips: createInitialTrips(),
    users: createSeedUsers(),
    tickets: [],
  };
  writeStore(initial);
  return initial;
}

function writeStore(store: PersistedStore): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const tmpPath = `${STORE_PATH}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(store, null, 2), 'utf8');
  fs.renameSync(tmpPath, STORE_PATH);
}

const FEMALE_SEAT_SET = new Set(['1A', '1B', '2A', '2B', '3A', '3B', '4C', '5C']);

function syncSeatsToCount(trip: BusTrip, targetAvailable: number): void {
  const clamped = Math.max(0, Math.min(trip.totalSeats, targetAvailable));
  let currentVacant = trip.seats.filter((s) => s.status !== 'occupied').length;

  if (currentVacant > clamped) {
    let toOccupy = currentVacant - clamped;
    // Prefer occupying general 'available' seats first from front-to-back, then 'female' if needed
    for (let i = 0; i < trip.seats.length && toOccupy > 0; i++) {
      if (trip.seats[i].status === 'available') {
        trip.seats[i].status = 'occupied';
        toOccupy--;
      }
    }
    for (let i = 0; i < trip.seats.length && toOccupy > 0; i++) {
      if (trip.seats[i].status === 'female') {
        trip.seats[i].status = 'occupied';
        toOccupy--;
      }
    }
  } else if (currentVacant < clamped) {
    let toFree = clamped - currentVacant;
    for (let i = trip.seats.length - 1; i >= 0 && toFree > 0; i--) {
      if (trip.seats[i].status === 'occupied') {
        trip.seats[i].status = FEMALE_SEAT_SET.has(trip.seats[i].seatNumber) ? 'female' : 'available';
        toFree--;
      }
    }
  }

  trip.availableSeats = trip.seats.filter((s) => s.status !== 'occupied').length;
}

class TransitDataStore {
  private data: PersistedStore;

  constructor() {
    this.data = ensureStoreLoaded();
  }

  getRoutes(): RuralRoute[] {
    return this.data.routes;
  }

  getRouteById(routeId: string): RuralRoute | undefined {
    return this.data.routes.find((r) => r.id === routeId);
  }

  getTrips(): BusTrip[] {
    return this.data.trips;
  }

  getTripById(tripId: string): BusTrip | undefined {
    return this.data.trips.find((t) => t.tripId === tripId);
  }

  getUserById = (id: string): StoredUser | undefined => {
    return this.data.users.find((u) => u.id === id);
  };

  getUserByIdentifier(identifier: string): StoredUser | undefined {
    const normalized = identifier.trim().toLowerCase();
    return this.data.users.find((u) => u.identifier.toLowerCase() === normalized);
  }

  createUser(user: StoredUser): StoredUser {
    this.data.users.push(user);
    writeStore(this.data);
    return user;
  }

  adjustTripSeats(
    tripId: string,
    opts: {
      delta?: number;
      mode?: 'delta' | 'standing' | 'full';
      conductorName: string;
    }
  ): BusTrip | null {
    const trip = this.getTripById(tripId);
    if (!trip) return null;

    const previousSeats = trip.availableSeats;
    let actionLabel = '';

    if (opts.mode === 'standing') {
      syncSeatsToCount(trip, 0);
      trip.status = 'Standing Only';
      actionLabel = 'Marked Standing Only';
    } else if (opts.mode === 'full') {
      syncSeatsToCount(trip, 0);
      trip.status = 'Full';
      actionLabel = 'Marked Bus Full';
    } else {
      const delta = typeof opts.delta === 'number' ? Math.trunc(opts.delta) : 0;
      const nextCount = Math.max(0, Math.min(trip.totalSeats, previousSeats + delta));
      syncSeatsToCount(trip, nextCount);
      trip.status = deriveAvailabilityStatus(trip.availableSeats, false);
      actionLabel = delta >= 0 ? `Added +${delta} Vacant` : `Boarded ${delta} Seats`;
    }

    const now = new Date().toISOString();
    trip.lastUpdatedAt = now;
    trip.recentLogs = [
      {
        id: `log-${crypto.randomUUID().slice(0, 8)}`,
        actionLabel,
        previousSeats,
        newSeats: trip.availableSeats,
        conductorName: opts.conductorName,
        timestamp: now,
      },
      ...trip.recentLogs,
    ].slice(0, 12);

    writeStore(this.data);
    return trip;
  }

  recordCrowdPing(tripId: string, ping: CrowdPing): BusTrip | null {
    const trip = this.getTripById(tripId);
    if (!trip) return null;

    trip.crowdPing = ping;
    trip.lastUpdatedAt = ping.reportedAt;

    if (ping.level === 'Standing Only' && trip.availableSeats === 0) {
      trip.status = 'Standing Only';
    } else if (ping.level === 'Bus Full' && trip.availableSeats === 0) {
      trip.status = 'Full';
    }

    writeStore(this.data);
    return trip;
  }

  bookTicketAndReserveSeats(
    tripId: string,
    seatNumbers: string[],
    ticketFactory: (trip: BusTrip, route: RuralRoute) => TicketPass
  ): { trip: BusTrip; ticket: TicketPass } | { error: string; statusCode: number } {
    const trip = this.getTripById(tripId);
    if (!trip) {
      return { error: 'Bus trip not found.', statusCode: 404 };
    }
    const route = this.getRouteById(trip.routeId);
    if (!route) {
      return { error: 'Bus route not found.', statusCode: 404 };
    }

    const requestedSet = new Set(seatNumbers);
    if (requestedSet.size === 0 || requestedSet.size !== seatNumbers.length) {
      return { error: 'Select at least one unique seat number.', statusCode: 400 };
    }
    if (requestedSet.size > 6) {
      return { error: 'Maximum 6 seats can be booked per pass.', statusCode: 400 };
    }

    for (const num of requestedSet) {
      const seat = trip.seats.find((s) => s.seatNumber === num);
      if (!seat) {
        return { error: `Seat ${num} does not exist on this bus.`, statusCode: 400 };
      }
      if (seat.status === 'occupied') {
        return { error: `Seat ${num} was just taken by another passenger. Please pick another seat.`, statusCode: 409 };
      }
    }

    const previousSeats = trip.availableSeats;
    for (const seat of trip.seats) {
      if (requestedSet.has(seat.seatNumber)) {
        seat.status = 'occupied';
      }
    }

    trip.availableSeats = trip.seats.filter((s) => s.status !== 'occupied').length;
    trip.status = deriveAvailabilityStatus(trip.availableSeats, false);
    const now = new Date().toISOString();
    trip.lastUpdatedAt = now;
    trip.recentLogs = [
      {
        id: `log-${crypto.randomUUID().slice(0, 8)}`,
        actionLabel: `QR Pass Issued (${seatNumbers.join(', ')})`,
        previousSeats,
        newSeats: trip.availableSeats,
        conductorName: 'Digital UPI Booking',
        timestamp: now,
      },
      ...trip.recentLogs,
    ].slice(0, 12);

    const ticket = ticketFactory(trip, route);
    this.data.tickets.unshift(ticket);
    writeStore(this.data);

    return { trip, ticket };
  }

  getTicketsByUser(userId: string): TicketPass[] {
    return this.data.tickets.filter((t) => t.userId === userId);
  }

  resetTripsForDemo(): BusTrip[] {
    const freshTrips = createInitialTrips();
    this.data.trips = freshTrips.map((t) => ({
      ...t,
      seats: buildSeatLayout(t.availableSeats),
      status: t.status as TripAvailabilityStatus,
    }));
    writeStore(this.data);
    return this.data.trips;
  }
}

export const transitStore = new TransitDataStore();
