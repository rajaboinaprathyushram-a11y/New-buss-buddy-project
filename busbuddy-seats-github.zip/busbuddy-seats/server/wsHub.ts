import type { Server as HttpServer } from 'http';
import { WebSocket, WebSocketServer } from 'ws';
import type { BusTrip, RealtimeEvent } from '../shared/transit';

export class RealtimeWsHub {
  private wss: WebSocketServer;

  constructor(httpServer: HttpServer, getTripsSnapshot: () => BusTrip[]) {
    this.wss = new WebSocketServer({ server: httpServer, path: '/ws' });

    this.wss.on('connection', (socket) => {
      const snapshot: RealtimeEvent = {
        type: 'trips:snapshot',
        trips: getTripsSnapshot(),
      };
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify(snapshot));
      }
    });
  }

  broadcast(event: RealtimeEvent): void {
    const payload = JSON.stringify(event);
    for (const client of this.wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
      }
    }
  }
}
