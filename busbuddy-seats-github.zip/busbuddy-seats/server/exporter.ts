import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

const ROOT_FILES = [
  '.gitignore',
  '.env.example',
  'package.json',
  'tsconfig.json',
  'vite.config.ts',
  'index.html',
  'metadata.json',
  'server.ts',
  'README.md',
];

const SOURCE_DIRS = ['shared', 'server', 'src'];
const ALLOWED_EXTS = new Set(['.ts', '.tsx', '.css', '.html', '.json', '.md']);

function collectFiles(rootDir: string): Record<string, string> {
  const files: Record<string, string> = {};

  for (const rel of ROOT_FILES) {
    const abs = path.join(rootDir, rel);
    if (fs.existsSync(abs) && fs.statSync(abs).isFile()) {
      files[rel] = fs.readFileSync(abs, 'utf8');
    }
  }

  const walk = (dirRel: string) => {
    const absDir = path.join(rootDir, dirRel);
    if (!fs.existsSync(absDir)) return;
    for (const entry of fs.readdirSync(absDir, { withFileTypes: true })) {
      if (entry.name === 'data' || entry.name === 'node_modules' || entry.name === 'dist') {
        continue;
      }
      const entryRel = path.posix.join(dirRel, entry.name);
      const entryAbs = path.join(rootDir, entryRel);
      if (entry.isDirectory()) {
        walk(entryRel);
      } else if (entry.isFile() && ALLOWED_EXTS.has(path.extname(entry.name))) {
        files[entryRel] = fs.readFileSync(entryAbs, 'utf8');
      }
    }
  };

  for (const dir of SOURCE_DIRS) {
    walk(dir);
  }

  return files;
}

export function generateProjectSetupScript(): string {
  const rootDir = process.cwd();
  const files = collectFiles(rootDir);

  return `import fs from 'fs';
import path from 'path';

const FILES = ${JSON.stringify(files, null, 2)};

const targetRoot = process.cwd();
let count = 0;

for (const [relPath, content] of Object.entries(FILES)) {
  const dest = path.resolve(targetRoot, relPath);
  if (!dest.startsWith(targetRoot + path.sep) && dest !== targetRoot) {
    throw new Error('Unsafe target path: ' + relPath);
  }
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, content, 'utf8');
  count++;
}

console.log('Created ' + count + ' normal project files in ' + targetRoot);
console.log('Next step: run "npm install" and then "npm run dev"');
`;
}

// Standard IEEE 802.3 CRC32 table for ZIP archive headers
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

export function generateProjectZipBuffer(): Buffer {
  const rootDir = process.cwd();
  const files = collectFiles(rootDir);

  const localParts: Buffer[] = [];
  const centralParts: Buffer[] = [];
  let offset = 0;
  let entryCount = 0;

  for (const [relPath, content] of Object.entries(files)) {
    const zipPath = `busbuddy-seats/${relPath}`;
    const nameBuf = Buffer.from(zipPath, 'utf8');
    const rawBuf = Buffer.from(content, 'utf8');
    const compressedBuf = zlib.deflateRawSync(rawBuf);
    const crc = crc32(rawBuf);

    // Local file header (30 bytes + filename)
    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0); // Local file header signature
    localHeader.writeUInt16LE(20, 4); // Version needed to extract (2.0)
    localHeader.writeUInt16LE(0x0800, 6); // UTF-8 filename flag
    localHeader.writeUInt16LE(8, 8); // Compression method: 8 = Deflate
    localHeader.writeUInt16LE(0, 10); // Mod time
    localHeader.writeUInt16LE(0x5421, 12); // Mod date
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(compressedBuf.length, 18);
    localHeader.writeUInt32LE(rawBuf.length, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28);

    localParts.push(localHeader, nameBuf, compressedBuf);

    // Central directory header (46 bytes + filename)
    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0); // Central directory signature
    centralHeader.writeUInt16LE(20, 4); // Version made by
    centralHeader.writeUInt16LE(20, 6); // Version needed
    centralHeader.writeUInt16LE(0x0800, 8); // UTF-8 flag
    centralHeader.writeUInt16LE(8, 10); // Deflate
    centralHeader.writeUInt16LE(0, 12); // Mod time
    centralHeader.writeUInt16LE(0x5421, 14); // Mod date
    centralHeader.writeUInt32LE(crc, 16);
    centralHeader.writeUInt32LE(compressedBuf.length, 20);
    centralHeader.writeUInt32LE(rawBuf.length, 24);
    centralHeader.writeUInt16LE(nameBuf.length, 28);
    centralHeader.writeUInt16LE(0, 30);
    centralHeader.writeUInt16LE(0, 32);
    centralHeader.writeUInt16LE(0, 34);
    centralHeader.writeUInt16LE(0, 36);
    centralHeader.writeUInt32LE(0, 38);
    centralHeader.writeUInt32LE(offset, 42); // Relative offset of local header

    centralParts.push(centralHeader, nameBuf);

    offset += localHeader.length + nameBuf.length + compressedBuf.length;
    entryCount++;
  }

  const centralDirBuf = Buffer.concat(centralParts);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); // End of central directory signature
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(entryCount, 8);
  eocd.writeUInt16LE(entryCount, 10);
  eocd.writeUInt32LE(centralDirBuf.length, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([...localParts, centralDirBuf, eocd]);
}
