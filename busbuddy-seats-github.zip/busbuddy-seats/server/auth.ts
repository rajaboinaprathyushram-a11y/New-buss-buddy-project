import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import type { UserProfile, UserRole } from '../shared/transit';

export interface StoredUser extends UserProfile {
  passwordHash: string;
}

const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const TOKEN_TTL_MS = 1000 * 60 * 60 * 12; // 12 hours

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const keyBuf = Buffer.from(keyHex, 'hex');
  const derivedBuf = crypto.scryptSync(password, salt, 64);
  if (keyBuf.length !== derivedBuf.length) return false;
  return crypto.timingSafeEqual(keyBuf, derivedBuf);
}

export function createSeedUsers(): StoredUser[] {
  return [
    {
      id: 'usr-student-1',
      name: 'Ravi Kumar (Student)',
      identifier: 'ravi.narsapur@rtc-demo.in',
      role: 'commuter',
      depotOrVillage: 'Narsapur Village',
      passwordHash: hashPassword('commuter123'),
    },
    {
      id: 'usr-conductor-312',
      name: 'Venkatesh Goud (Conductor #312)',
      identifier: 'venkat.312@rtc-demo.in',
      role: 'conductor',
      depotOrVillage: 'Medak RTC Depot',
      passwordHash: hashPassword('conductor123'),
    },
  ];
}

interface TokenPayload {
  sub: string;
  role: UserRole;
  exp: number;
}

export function signSessionToken(user: UserProfile): string {
  const payload: TokenPayload = {
    sub: user.id,
    role: user.role,
    exp: Date.now() + TOKEN_TTL_MS,
  };
  const encodedPayload = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encodedPayload)
    .digest('base64url');
  return `${encodedPayload}.${sig}`;
}

export function verifySessionToken(token: string): TokenPayload | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encodedPayload, providedSig] = parts;

  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encodedPayload)
    .digest('base64url');

  const providedBuf = Buffer.from(providedSig, 'utf8');
  const expectedBuf = Buffer.from(expectedSig, 'utf8');
  if (providedBuf.length !== expectedBuf.length) return null;
  if (!crypto.timingSafeEqual(providedBuf, expectedBuf)) return null;

  try {
    const parsed = JSON.parse(
      Buffer.from(encodedPayload, 'base64url').toString('utf8')
    ) as TokenPayload;
    if (!parsed.sub || !parsed.role || typeof parsed.exp !== 'number') return null;
    if (Date.now() > parsed.exp) return null;
    return parsed;
  } catch {
    return null;
  }
}

export interface AuthenticatedRequest extends Request {
  authUser?: UserProfile;
}

export function buildAuthMiddleware(getUserById: (id: string) => StoredUser | undefined) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Authentication required. Please sign in.' });
      return;
    }

    const token = header.slice('Bearer '.length).trim();
    const payload = verifySessionToken(token);
    if (!payload) {
      res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
      return;
    }

    const user = getUserById(payload.sub);
    if (!user) {
      res.status(401).json({ error: 'User account not found.' });
      return;
    }

    req.authUser = {
      id: user.id,
      name: user.name,
      identifier: user.identifier,
      role: user.role,
      depotOrVillage: user.depotOrVillage,
    };
    next();
  };
}
