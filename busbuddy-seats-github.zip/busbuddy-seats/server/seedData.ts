import type { BusSeat, BusTrip, RuralRoute, TripAvailabilityStatus } from '../shared/transit';

export const RURAL_ROUTES: RuralRoute[] = [
  {
    id: 'route-312',
    routeNumber: '312',
    name: 'Narsapur – Medak Town Express Feeder',
    busType: 'Express Feeder',
    baseFare: 15,
    stageRate: 10,
    stops: [
      { stopId: 'stp-narsapur', villageName: 'Narsapur', landmarkName: 'Gram Panchayat Gate', stageIndex: 0, distanceKm: 0, etaOffsetMins: 0 },
      { stopId: 'stp-kowdipally', villageName: 'Kowdipally', landmarkName: 'Primary School Junction', stageIndex: 1, distanceKm: 8, etaOffsetMins: 16 },
      { stopId: 'stp-kulcharam', villageName: 'Kulcharam', landmarkName: 'Near Banyan Tree / Mandal Office', stageIndex: 2, distanceKm: 15, etaOffsetMins: 30 },
      { stopId: 'stp-haveli', villageName: 'Haveli Ghanpur', landmarkName: 'Milk Collection Center', stageIndex: 3, distanceKm: 23, etaOffsetMins: 44 },
      { stopId: 'stp-medak', villageName: 'Medak Town', landmarkName: 'Medak Old RTC Bus Stand', stageIndex: 4, distanceKm: 31, etaOffsetMins: 60 },
    ],
  },
  {
    id: 'route-318',
    routeNumber: '318',
    name: 'Narsapur – Medak Town via Tekmal',
    busType: 'Palle Velugu',
    baseFare: 15,
    stageRate: 9,
    stops: [
      { stopId: 'stp-narsapur', villageName: 'Narsapur', landmarkName: 'Gram Panchayat Gate', stageIndex: 0, distanceKm: 0, etaOffsetMins: 0 },
      { stopId: 'stp-chegunta', villageName: 'Chegunta', landmarkName: 'Railway Crossing Turn', stageIndex: 1, distanceKm: 10, etaOffsetMins: 20 },
      { stopId: 'stp-tekmal', villageName: 'Tekmal', landmarkName: 'Temple Arch Bus Point', stageIndex: 2, distanceKm: 19, etaOffsetMins: 38 },
      { stopId: 'stp-medak', villageName: 'Medak Town', landmarkName: 'Medak Old RTC Bus Stand', stageIndex: 3, distanceKm: 33, etaOffsetMins: 65 },
    ],
  },
  {
    id: 'route-104',
    routeNumber: '104',
    name: 'Toopran – Gajwel Market Shuttle',
    busType: 'Palle Velugu',
    baseFare: 15,
    stageRate: 8,
    stops: [
      { stopId: 'stp-toopran', villageName: 'Toopran', landmarkName: 'Highway Flyover Circle', stageIndex: 0, distanceKm: 0, etaOffsetMins: 0 },
      { stopId: 'stp-masaipet', villageName: 'Masaipet', landmarkName: 'Opposite Gram Panchayat Office', stageIndex: 1, distanceKm: 9, etaOffsetMins: 18 },
      { stopId: 'stp-pregnapur', villageName: 'Pregnapur', landmarkName: 'Rythu Bazaar Shed', stageIndex: 2, distanceKm: 18, etaOffsetMins: 35 },
      { stopId: 'stp-gajwel', villageName: 'Gajwel', landmarkName: 'Gajwel Bus Terminal', stageIndex: 3, distanceKm: 24, etaOffsetMins: 48 },
    ],
  },
  {
    id: 'route-215',
    routeNumber: '215',
    name: 'Gajwel – Siddipet District Link',
    busType: 'Express Feeder',
    baseFare: 15,
    stageRate: 10,
    stops: [
      { stopId: 'stp-gajwel', villageName: 'Gajwel', landmarkName: 'Gajwel Bus Terminal', stageIndex: 0, distanceKm: 0, etaOffsetMins: 0 },
      { stopId: 'stp-mulugu', villageName: 'Mulugu', landmarkName: 'Forest Checkpost Gate', stageIndex: 1, distanceKm: 11, etaOffsetMins: 22 },
      { stopId: 'stp-kondapak', villageName: 'Kondapak', landmarkName: 'Water Tank Chowrasta', stageIndex: 2, distanceKm: 22, etaOffsetMins: 42 },
      { stopId: 'stp-siddipet', villageName: 'Siddipet', landmarkName: 'Siddipet New Bus Stand', stageIndex: 3, distanceKm: 34, etaOffsetMins: 64 },
    ],
  },
  {
    id: 'route-409',
    routeNumber: '409',
    name: 'Jogipet – Sangareddy College Special',
    busType: 'Express Feeder',
    baseFare: 15,
    stageRate: 10,
    stops: [
      { stopId: 'stp-jogipet', villageName: 'Jogipet', landmarkName: 'Degree College Gate', stageIndex: 0, distanceKm: 0, etaOffsetMins: 0 },
      { stopId: 'stp-papannapet', villageName: 'Papannapet', landmarkName: 'Primary Health Center', stageIndex: 1, distanceKm: 12, etaOffsetMins: 24 },
      { stopId: 'stp-shankarampet', villageName: 'Shankarampet', landmarkName: 'Weekly Shandy Ground', stageIndex: 2, distanceKm: 20, etaOffsetMins: 40 },
      { stopId: 'stp-sangareddy', villageName: 'Sangareddy', landmarkName: 'Collectorate Main Gate', stageIndex: 3, distanceKm: 32, etaOffsetMins: 62 },
    ],
  },
  {
    id: 'route-511',
    routeNumber: '511',
    name: 'Sangareddy – Zaheerabad Border Route',
    busType: 'Palle Velugu',
    baseFare: 15,
    stageRate: 10,
    stops: [
      { stopId: 'stp-sangareddy', villageName: 'Sangareddy', landmarkName: 'Collectorate Main Gate', stageIndex: 0, distanceKm: 0, etaOffsetMins: 0 },
      { stopId: 'stp-patancheru', villageName: 'Patancheru', landmarkName: 'Old Market Yard Corner', stageIndex: 1, distanceKm: 14, etaOffsetMins: 26 },
      { stopId: 'stp-zaheerabad', villageName: 'Zaheerabad', landmarkName: 'Zaheerabad Town Depot', stageIndex: 2, distanceKm: 42, etaOffsetMins: 75 },
    ],
  },
  {
    id: 'route-602',
    routeNumber: '602',
    name: 'Ramayampet – Medak Morning Feeder',
    busType: 'Village Ordinary',
    baseFare: 15,
    stageRate: 8,
    stops: [
      { stopId: 'stp-ramayampet', villageName: 'Ramayampet', landmarkName: 'NH-44 Cross Road', stageIndex: 0, distanceKm: 0, etaOffsetMins: 0 },
      { stopId: 'stp-tupranpet', villageName: 'Tupranpet', landmarkName: 'Cooperative Bank Stop', stageIndex: 1, distanceKm: 9, etaOffsetMins: 19 },
      { stopId: 'stp-haveli', villageName: 'Haveli Ghanpur', landmarkName: 'Milk Collection Center', stageIndex: 2, distanceKm: 17, etaOffsetMins: 36 },
      { stopId: 'stp-medak', villageName: 'Medak Town', landmarkName: 'Medak Old RTC Bus Stand', stageIndex: 3, distanceKm: 26, etaOffsetMins: 54 },
    ],
  },
  {
    id: 'route-708',
    routeNumber: '708',
    name: 'Dubbak – Siddipet Mandal Loop',
    busType: 'Village Ordinary',
    baseFare: 15,
    stageRate: 8,
    stops: [
      { stopId: 'stp-dubbak', villageName: 'Dubbak', landmarkName: 'Handloom Society Gate', stageIndex: 0, distanceKm: 0, etaOffsetMins: 0 },
      { stopId: 'stp-wargal', villageName: 'Wargal', landmarkName: 'Saraswati Temple Steps', stageIndex: 1, distanceKm: 11, etaOffsetMins: 24 },
      { stopId: 'stp-kondapak', villageName: 'Kondapak', landmarkName: 'Water Tank Chowrasta', stageIndex: 2, distanceKm: 19, etaOffsetMins: 40 },
      { stopId: 'stp-siddipet', villageName: 'Siddipet', landmarkName: 'Siddipet New Bus Stand', stageIndex: 3, distanceKm: 28, etaOffsetMins: 58 },
    ],
  },
  {
    id: 'route-804',
    routeNumber: '804',
    name: 'Narayankhed – Jogipet Rural Express',
    busType: 'Express Feeder',
    baseFare: 15,
    stageRate: 10,
    stops: [
      { stopId: 'stp-narayankhed', villageName: 'Narayankhed', landmarkName: 'Agricultural Market Gate', stageIndex: 0, distanceKm: 0, etaOffsetMins: 0 },
      { stopId: 'stp-shankarampet', villageName: 'Shankarampet', landmarkName: 'Weekly Shandy Ground', stageIndex: 1, distanceKm: 15, etaOffsetMins: 30 },
      { stopId: 'stp-jogipet', villageName: 'Jogipet', landmarkName: 'Degree College Gate', stageIndex: 2, distanceKm: 29, etaOffsetMins: 56 },
    ],
  },
  {
    id: 'route-901',
    routeNumber: '901',
    name: 'Narsapur – Patancheru Industrial Link',
    busType: 'Palle Velugu',
    baseFare: 15,
    stageRate: 9,
    stops: [
      { stopId: 'stp-narsapur', villageName: 'Narsapur', landmarkName: 'Gram Panchayat Gate', stageIndex: 0, distanceKm: 0, etaOffsetMins: 0 },
      { stopId: 'stp-kowdipally', villageName: 'Kowdipally', landmarkName: 'Primary School Junction', stageIndex: 1, distanceKm: 8, etaOffsetMins: 17 },
      { stopId: 'stp-patancheru', villageName: 'Patancheru', landmarkName: 'Old Market Yard Corner', stageIndex: 2, distanceKm: 24, etaOffsetMins: 48 },
      { stopId: 'stp-sangareddy', villageName: 'Sangareddy', landmarkName: 'Collectorate Main Gate', stageIndex: 3, distanceKm: 36, etaOffsetMins: 70 },
    ],
  },
];

const SEAT_LETTERS = ['A', 'B', 'C', 'D', 'E'] as const;
const TOTAL_ROWS = 9; // 9 rows x 5 seats (2x3 layout) = 45 seats
const FEMALE_RESERVED_SEATS = new Set(['1A', '1B', '2A', '2B', '3A', '3B', '4C', '5C']);

export function buildSeatLayout(availableSeats: number): BusSeat[] {
  const totalSeats = TOTAL_ROWS * SEAT_LETTERS.length;
  const clampedAvailable = Math.max(0, Math.min(totalSeats, availableSeats));
  const seats: BusSeat[] = [];

  for (let row = 1; row <= TOTAL_ROWS; row++) {
    for (let colIndex = 0; colIndex < SEAT_LETTERS.length; colIndex++) {
      const letter = SEAT_LETTERS[colIndex];
      const seatNumber = `${row}${letter}`;
      seats.push({
        seatNumber,
        row,
        column: colIndex + 1,
        side: colIndex < 2 ? 'left' : 'right',
        isWindow: colIndex === 0 || colIndex === 4,
        status: 'occupied',
      });
    }
  }

  // Fill vacant seats from the back/mid rows first, preserving some female-reserved seats
  // while guaranteeing seats.filter(s => s.status !== 'occupied').length === clampedAvailable
  let remainingVacant = clampedAvailable;

  // First allocate up to 4 female-reserved vacant seats if enough seats are available
  const femaleIndices = seats
    .map((s, idx) => (FEMALE_RESERVED_SEATS.has(s.seatNumber) ? idx : -1))
    .filter((idx) => idx >= 0);

  const femaleToOpen = clampedAvailable >= 8 ? Math.min(4, femaleIndices.length) : Math.min(1, clampedAvailable);
  for (let i = 0; i < femaleToOpen && remainingVacant > 0; i++) {
    seats[femaleIndices[i]].status = 'female';
    remainingVacant--;
  }

  // Next fill remaining vacant seats evenly across middle & rear rows
  for (let idx = seats.length - 1; idx >= 0 && remainingVacant > 0; idx--) {
    if (seats[idx].status === 'occupied' && !FEMALE_RESERVED_SEATS.has(seats[idx].seatNumber)) {
      seats[idx].status = 'available';
      remainingVacant--;
    }
  }

  // Fallback if female seats were the only ones left
  for (let idx = 0; idx < seats.length && remainingVacant > 0; idx++) {
    if (seats[idx].status === 'occupied') {
      seats[idx].status = FEMALE_RESERVED_SEATS.has(seats[idx].seatNumber) ? 'female' : 'available';
      remainingVacant--;
    }
  }

  return seats;
}

export function deriveAvailabilityStatus(availableSeats: number, standingAllowed = false): TripAvailabilityStatus {
  if (availableSeats > 0) return 'Available';
  return standingAllowed ? 'Standing Only' : 'Full';
}

export function createInitialTrips(): BusTrip[] {
  const nowIso = new Date().toISOString();

  const configs: Array<{
    tripId: string;
    routeId: string;
    routeNumber: string;
    busRegistration: string;
    departureTime: string;
    departureInMins: number;
    availableSeats: number;
    status?: TripAvailabilityStatus;
    currentStopName: string;
    crowdLevel?: BusTrip['crowdPing'];
  }> = [
    {
      tripId: 'TRIP-312-A',
      routeId: 'route-312',
      routeNumber: '312',
      busRegistration: 'TS-35-Z-0312',
      departureTime: '09:40 AM',
      departureInMins: 20,
      availableSeats: 14,
      currentStopName: 'Narsapur · Gram Panchayat Gate',
      crowdLevel: {
        level: 'Seats Plenty',
        reportedBy: 'Suresh K. (Commuter)',
        stopName: 'Narsapur · Gram Panchayat Gate',
        reportedAt: nowIso,
      },
    },
    {
      tripId: 'TRIP-318-A',
      routeId: 'route-318',
      routeNumber: '318',
      busRegistration: 'TS-35-Z-0318',
      departureTime: '10:05 AM',
      departureInMins: 45,
      availableSeats: 22,
      currentStopName: 'Narsapur · Gram Panchayat Gate',
      crowdLevel: null,
    },
    {
      tripId: 'TRIP-104-A',
      routeId: 'route-104',
      routeNumber: '104',
      busRegistration: 'TS-36-Z-0104',
      departureTime: '09:35 AM',
      departureInMins: 15,
      availableSeats: 6,
      currentStopName: 'Toopran · Highway Flyover Circle',
      crowdLevel: {
        level: 'Bus is 80% Full',
        reportedBy: 'Lakshmi M. (Commuter)',
        stopName: 'Masaipet · Opposite Gram Panchayat Office',
        reportedAt: nowIso,
      },
    },
    {
      tripId: 'TRIP-215-A',
      routeId: 'route-215',
      routeNumber: '215',
      busRegistration: 'TS-36-Z-0215',
      departureTime: '09:55 AM',
      departureInMins: 35,
      availableSeats: 0,
      status: 'Standing Only',
      currentStopName: 'Mulugu · Forest Checkpost Gate',
      crowdLevel: {
        level: 'Standing Only',
        reportedBy: 'Anil R. (Student)',
        stopName: 'Mulugu · Forest Checkpost Gate',
        reportedAt: nowIso,
      },
    },
    {
      tripId: 'TRIP-409-A',
      routeId: 'route-409',
      routeNumber: '409',
      busRegistration: 'TS-15-Z-0409',
      departureTime: '09:50 AM',
      departureInMins: 30,
      availableSeats: 18,
      currentStopName: 'Jogipet · Degree College Gate',
      crowdLevel: null,
    },
    {
      tripId: 'TRIP-511-A',
      routeId: 'route-511',
      routeNumber: '511',
      busRegistration: 'TS-15-Z-0511',
      departureTime: '10:20 AM',
      departureInMins: 60,
      availableSeats: 29,
      currentStopName: 'Sangareddy · Collectorate Main Gate',
      crowdLevel: null,
    },
    {
      tripId: 'TRIP-602-A',
      routeId: 'route-602',
      routeNumber: '602',
      busRegistration: 'TS-35-Z-0602',
      departureTime: '09:30 AM',
      departureInMins: 10,
      availableSeats: 0,
      status: 'Full',
      currentStopName: 'Tupranpet · Cooperative Bank Stop',
      crowdLevel: {
        level: 'Bus Full',
        reportedBy: 'Mahesh P. (Commuter)',
        stopName: 'Tupranpet · Cooperative Bank Stop',
        reportedAt: nowIso,
      },
    },
    {
      tripId: 'TRIP-708-A',
      routeId: 'route-708',
      routeNumber: '708',
      busRegistration: 'TS-36-Z-0708',
      departureTime: '10:15 AM',
      departureInMins: 55,
      availableSeats: 16,
      currentStopName: 'Dubbak · Handloom Society Gate',
      crowdLevel: null,
    },
    {
      tripId: 'TRIP-804-A',
      routeId: 'route-804',
      routeNumber: '804',
      busRegistration: 'TS-15-Z-0804',
      departureTime: '10:30 AM',
      departureInMins: 70,
      availableSeats: 24,
      currentStopName: 'Narayankhed · Agricultural Market Gate',
      crowdLevel: null,
    },
    {
      tripId: 'TRIP-901-A',
      routeId: 'route-901',
      routeNumber: '901',
      busRegistration: 'TS-35-Z-0901',
      departureTime: '09:48 AM',
      departureInMins: 28,
      availableSeats: 9,
      currentStopName: 'Narsapur · Gram Panchayat Gate',
      crowdLevel: null,
    },
  ];

  return configs.map((cfg) => ({
    tripId: cfg.tripId,
    routeId: cfg.routeId,
    routeNumber: cfg.routeNumber,
    busRegistration: cfg.busRegistration,
    departureTime: cfg.departureTime,
    departureInMins: cfg.departureInMins,
    totalSeats: 45,
    availableSeats: cfg.availableSeats,
    status: cfg.status ?? deriveAvailabilityStatus(cfg.availableSeats),
    currentStopName: cfg.currentStopName,
    seats: buildSeatLayout(cfg.availableSeats),
    crowdPing: cfg.crowdLevel ?? null,
    recentLogs: [],
    lastUpdatedAt: nowIso,
  }));
}
