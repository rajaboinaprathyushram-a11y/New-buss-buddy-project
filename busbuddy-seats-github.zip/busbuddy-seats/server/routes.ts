import crypto from 'crypto';
import express from 'express';
import { calculateStageFare } from '../shared/fare';
import type { CrowdLevel, TicketPass, UserProfile } from '../shared/transit';
import {
  buildAuthMiddleware,
  hashPassword,
  signSessionToken,
  verifyPassword,
  type AuthenticatedRequest,
} from './auth';
import { transitStore } from './storage';
import type { RealtimeWsHub } from './wsHub';

const ALLOWED_CROWD_LEVELS = new Set<CrowdLevel>([
  'Seats Plenty',
  'Bus is 80% Full',
  'Standing Only',
  'Bus Full',
]);

function toPublicUser(user: UserProfile & { passwordHash?: string }): UserProfile {
  return {
    id: user.id,
    name: user.name,
    identifier: user.identifier,
    role: user.role,
    depotOrVillage: user.depotOrVillage,
  };
}

export function createApiRouter(wsHub: RealtimeWsHub): express.Router {
  const router = express.Router();
  const requireAuth = buildAuthMiddleware(transitStore.getUserById);

  router.get('/health', (_req, res) => {
    res.json({ ok: true });
  });

  // Authentication
  router.post('/auth/login', (req, res) => {
    const { identifier, password } = req.body ?? {};
    if (typeof identifier !== 'string' || typeof password !== 'string' || !identifier.trim() || !password) {
      res.status(400).json({ error: 'Please enter both your email/phone and password.' });
      return;
    }

    const user = transitStore.getUserByIdentifier(identifier);
    if (!user || !verifyPassword(password, user.passwordHash)) {
      res.status(401).json({ error: 'Invalid credentials. Check your ID and password or use a demo account.' });
      return;
    }

    const publicUser = toPublicUser(user);
    const token = signSessionToken(publicUser);
    res.json({ token, user: publicUser });
  });

  router.post('/auth/register', (req, res) => {
    const { name, identifier, password, depotOrVillage } = req.body ?? {};
    if (typeof name !== 'string' || name.trim().length < 2) {
      res.status(400).json({ error: 'Please enter your full name (at least 2 characters).' });
      return;
    }
    if (typeof identifier !== 'string' || identifier.trim().length < 4) {
      res.status(400).json({ error: 'Please enter a valid email or 10-digit mobile number.' });
      return;
    }
    if (typeof password !== 'string' || password.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters long.' });
      return;
    }
    if (transitStore.getUserByIdentifier(identifier)) {
      res.status(409).json({ error: 'An account with this email or mobile number already exists.' });
      return;
    }

    const created = transitStore.createUser({
      id: `usr-${crypto.randomUUID().slice(0, 8)}`,
      name: name.trim(),
      identifier: identifier.trim().toLowerCase(),
      role: 'commuter',
      depotOrVillage: typeof depotOrVillage === 'string' && depotOrVillage.trim()
        ? depotOrVillage.trim()
        : 'Rural Commuter',
      passwordHash: hashPassword(password),
    });

    const publicUser = toPublicUser(created);
    const token = signSessionToken(publicUser);
    res.status(201).json({ token, user: publicUser });
  });

  router.get('/auth/me', requireAuth, (req: AuthenticatedRequest, res) => {
    res.json({ user: req.authUser });
  });

  // Rural Routes & Live Trips
  router.get('/routes', (_req, res) => {
    res.json({ routes: transitStore.getRoutes() });
  });

  router.get('/trips', (req, res) => {
    const origin = typeof req.query.origin === 'string' ? req.query.origin.trim().toLowerCase() : '';
    const destination = typeof req.query.destination === 'string' ? req.query.destination.trim().toLowerCase() : '';
    const query = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';

    const routes = transitStore.getRoutes();
    const trips = transitStore.getTrips().filter((trip) => {
      const route = routes.find((r) => r.id === trip.routeId);
      if (!route) return false;

      if (origin && destination) {
        const originIdx = route.stops.findIndex((s) => s.villageName.toLowerCase() === origin);
        const destIdx = route.stops.findIndex((s) => s.villageName.toLowerCase() === destination);
        if (originIdx === -1 || destIdx === -1 || originIdx >= destIdx) {
          return false;
        }
      } else if (origin) {
        const hasOrigin = route.stops.some((s) => s.villageName.toLowerCase() === origin);
        if (!hasOrigin) return false;
      } else if (destination) {
        const hasDest = route.stops.some((s) => s.villageName.toLowerCase() === destination);
        if (!hasDest) return false;
      }

      if (query) {
        const matchesRoute =
          route.routeNumber.toLowerCase().includes(query) ||
          route.name.toLowerCase().includes(query) ||
          trip.busRegistration.toLowerCase().includes(query);
        const matchesStop = route.stops.some(
          (s) =>
            s.villageName.toLowerCase().includes(query) ||
            s.landmarkName.toLowerCase().includes(query)
        );
        if (!matchesRoute && !matchesStop) return false;
      }

      return true;
    });

    res.json({ trips, routes });
  });

  // Conductor Quick-Update Seat Count
  router.post('/trips/:tripId/seats', requireAuth, (req: AuthenticatedRequest, res) => {
    if (req.authUser?.role !== 'conductor') {
      res.status(403).json({ error: 'Conductor account required to update official bus seat counts.' });
      return;
    }

    const { tripId } = req.params;
    const { delta, mode } = req.body ?? {};

    if (mode !== 'standing' && mode !== 'full') {
      if (typeof delta !== 'number' || !Number.isFinite(delta) || Math.abs(delta) > 45) {
        res.status(400).json({ error: 'Seat delta must be a finite number between -45 and +45.' });
        return;
      }
    }

    const updated = transitStore.adjustTripSeats(tripId, {
      delta: typeof delta === 'number' ? delta : undefined,
      mode: mode === 'standing' || mode === 'full' ? mode : 'delta',
      conductorName: req.authUser.name,
    });

    if (!updated) {
      res.status(404).json({ error: 'Trip not found.' });
      return;
    }

    wsHub.broadcast({ type: 'trip:updated', trip: updated });
    res.json({ trip: updated });
  });

  // Reset demo state for clean college presentation re-runs
  router.post('/trips/reset-demo', requireAuth, (req: AuthenticatedRequest, res) => {
    if (req.authUser?.role !== 'conductor') {
      res.status(403).json({ error: 'Conductor account required to reset demo trip seats.' });
      return;
    }

    const trips = transitStore.resetTripsForDemo();
    wsHub.broadcast({ type: 'trips:snapshot', trips });
    res.json({ trips });
  });

  // Crowd-Sourced Occupancy Ping
  router.post('/trips/:tripId/crowd-ping', requireAuth, (req: AuthenticatedRequest, res) => {
    const { tripId } = req.params;
    const { level, stopName } = req.body ?? {};

    if (typeof level !== 'string' || !ALLOWED_CROWD_LEVELS.has(level as CrowdLevel)) {
      res.status(400).json({ error: 'Invalid crowd level specified.' });
      return;
    }

    const updated = transitStore.recordCrowdPing(tripId, {
      level: level as CrowdLevel,
      reportedBy: req.authUser!.name,
      stopName: typeof stopName === 'string' && stopName.trim() ? stopName.trim() : 'En route',
      reportedAt: new Date().toISOString(),
    });

    if (!updated) {
      res.status(404).json({ error: 'Trip not found.' });
      return;
    }

    wsHub.broadcast({ type: 'trip:updated', trip: updated });
    res.json({ trip: updated });
  });

  // Passenger Tickets & UPI QR Payment Confirmation
  router.get('/tickets', requireAuth, (req: AuthenticatedRequest, res) => {
    const tickets = transitStore.getTicketsByUser(req.authUser!.id);
    res.json({ tickets });
  });

  router.post('/tickets', requireAuth, (req: AuthenticatedRequest, res) => {
    const {
      tripId,
      passengerName,
      passengerPhone,
      boardingStopId,
      dropStopId,
      seatNumbers,
      studentConcession,
      studentPassId,
      upiRef,
    } = req.body ?? {};

    if (typeof tripId !== 'string' || !tripId.trim()) {
      res.status(400).json({ error: 'Trip ID is required.' });
      return;
    }
    if (typeof passengerName !== 'string' || passengerName.trim().length < 2) {
      res.status(400).json({ error: 'Passenger full name is required.' });
      return;
    }
    if (typeof passengerPhone !== 'string' || !/^[6-9]\d{9}$/.test(passengerPhone.trim())) {
      res.status(400).json({ error: 'Enter a valid 10-digit Indian mobile number starting with 6-9.' });
      return;
    }
    if (!Array.isArray(seatNumbers) || seatNumbers.length === 0 || !seatNumbers.every((s) => typeof s === 'string')) {
      res.status(400).json({ error: 'Select at least one seat from the 2x3 seat layout.' });
      return;
    }
    if (studentConcession && (typeof studentPassId !== 'string' || studentPassId.trim().length < 4)) {
      res.status(400).json({ error: 'Enter a valid Student Bus Pass ID to claim concession.' });
      return;
    }
    if (typeof upiRef !== 'string' || upiRef.trim().length < 6) {
      res.status(400).json({ error: 'Enter or confirm the UPI Transaction Reference ID.' });
      return;
    }

    const tripPreview = transitStore.getTripById(tripId);
    if (!tripPreview) {
      res.status(404).json({ error: 'Bus trip not found.' });
      return;
    }
    const route = transitStore.getRouteById(tripPreview.routeId);
    if (!route) {
      res.status(404).json({ error: 'Bus route not found.' });
      return;
    }

    const boardingStop = route.stops.find((s) => s.stopId === boardingStopId);
    const dropStop = route.stops.find((s) => s.stopId === dropStopId);
    if (!boardingStop || !dropStop || boardingStop.stageIndex >= dropStop.stageIndex) {
      res.status(400).json({ error: 'Drop stop must come after the boarding landmark stop.' });
      return;
    }

    const fare = calculateStageFare(
      route,
      boardingStop,
      dropStop,
      seatNumbers.length,
      Boolean(studentConcession)
    );

    const result = transitStore.bookTicketAndReserveSeats(
      tripId,
      seatNumbers,
      (updatedTrip, matchedRoute): TicketPass => ({
        ticketId: `BB-${updatedTrip.routeNumber}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
        tripId: updatedTrip.tripId,
        routeNumber: matchedRoute.routeNumber,
        routeName: matchedRoute.name,
        busRegistration: updatedTrip.busRegistration,
        departureTime: updatedTrip.departureTime,
        passengerName: passengerName.trim(),
        passengerPhone: passengerPhone.trim(),
        boardingVillage: boardingStop.villageName,
        boardingLandmark: boardingStop.landmarkName,
        dropVillage: dropStop.villageName,
        dropLandmark: dropStop.landmarkName,
        seatNumbers: [...seatNumbers],
        stages: fare.stages,
        studentConcession: Boolean(studentConcession),
        studentPassId: studentConcession ? String(studentPassId).trim().toUpperCase() : undefined,
        farePaid: fare.finalFare,
        upiId: 'ruralrtc.medak@upi',
        upiRef: upiRef.trim().toUpperCase(),
        issuedAt: new Date().toISOString(),
        userId: req.authUser!.id,
      })
    );

    if ('error' in result) {
      res.status(result.statusCode).json({ error: result.error });
      return;
    }

    wsHub.broadcast({
      type: 'ticket:booked',
      trip: result.trip,
      ticketId: result.ticket.ticketId,
    });
    res.status(201).json(result);
  });

  return router;
}
