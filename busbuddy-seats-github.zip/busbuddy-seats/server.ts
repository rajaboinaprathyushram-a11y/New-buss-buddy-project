import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { generateProjectSetupScript, generateProjectZipBuffer } from './server/exporter';
import { createApiRouter } from './server/routes';
import { transitStore } from './server/storage';
import { RealtimeWsHub } from './server/wsHub';

const PORT = Number(process.env.PORT) || 3000;
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

async function startServer() {
  const app = express();
  const httpServer = http.createServer(app);

  app.use(express.json({ limit: '1mb' }));

  const wsHub = new RealtimeWsHub(httpServer, () => transitStore.getTrips());
  app.use('/api', createApiRouter(wsHub));

  app.get('/setup-busbuddy.mjs', (_req, res) => {
    const script = generateProjectSetupScript();
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="setup-busbuddy.mjs"');
    res.send(script);
  });

  app.get('/busbuddy-seats-github.zip', (_req, res) => {
    const zipBuffer = generateProjectZipBuffer();
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="busbuddy-seats-github.zip"');
    res.send(zipBuffer);
  });

  if (!IS_PRODUCTION) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`BusBuddy Seats server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start BusBuddy Seats server:', err);
  process.exit(1);
});
